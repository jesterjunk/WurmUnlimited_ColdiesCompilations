package org.coldie.wurmunlimited.mods.DPS;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.gotti.wurmunlimited.modloader.classhooks.HookException;
import org.gotti.wurmunlimited.modloader.classhooks.HookManager;
import org.gotti.wurmunlimited.modloader.classhooks.InvocationHandlerFactory;
import org.gotti.wurmunlimited.modloader.interfaces.Configurable;
import org.gotti.wurmunlimited.modloader.interfaces.Initable;
import org.gotti.wurmunlimited.modloader.interfaces.PlayerLoginListener;
import org.gotti.wurmunlimited.modloader.interfaces.PlayerMessageListener;
import org.gotti.wurmunlimited.modloader.interfaces.ServerStartedListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.ModSupportDb;

import com.wurmonline.server.Server;
import com.wurmonline.server.creatures.Communicator;
import com.wurmonline.server.creatures.Creature;
import com.wurmonline.server.players.Player;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtPrimitiveType;
import javassist.NotFoundException;
import javassist.bytecode.Descriptor;
import javassist.expr.ExprEditor;
import javassist.expr.MethodCall;

public class DPS implements WurmServerMod, Configurable, Initable, PlayerMessageListener, PlayerLoginListener, ServerStartedListener {
	static Logger logger = Logger.getLogger(DPS.class.getName());
    
    public String getVersion() {
        return "v3.0";
    }
   
	static double damage = 0;
	static int minid = 42; // black bear
	static int maxid = 42;
	public void dpshook(){
			try {
        	ClassPool classPool = HookManager.getInstance().getClassPool();
     	
        	//public static boolean addWound(@Nullable Creature performer, Creature defender, 
        	//byte type, int pos, double damage, float armourMod, String attString, 
        	//@Nullable Battle battle, float infection, float poison, boolean archery, 
        	//boolean alreadyCalculatedResist, boolean noMinimumDamage, boolean spell)
        	  
        	  
        	  
            String descriptor = Descriptor.ofMethod(CtPrimitiveType.booleanType, new CtClass[] {
            		classPool.get("com.wurmonline.server.creatures.Creature"),
            		classPool.get("com.wurmonline.server.creatures.Creature"),
            		CtPrimitiveType.byteType,
            		CtPrimitiveType.intType,
            		CtPrimitiveType.doubleType,
            		CtPrimitiveType.floatType,
            		classPool.get("java.lang.String"),
            		classPool.get("com.wurmonline.server.combat.Battle"),
            		CtPrimitiveType.floatType,
            		CtPrimitiveType.floatType,
            		CtPrimitiveType.booleanType,
            		CtPrimitiveType.booleanType,            		
            		CtPrimitiveType.booleanType,
            		CtPrimitiveType.booleanType
            });       	
               HookManager.getInstance().registerHook("com.wurmonline.server.combat.CombatEngine", "addWound", descriptor, new InvocationHandlerFactory(){
 
            	@Override 
                        public InvocationHandler createInvocationHandler(){
                            return new InvocationHandler(){
                                @Override
                                public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                                	
                                	//0 performer, 1 defender, 2 type, 3 pos, 
                                	//4 damage, 5 armourMod,
                                	Creature performer = (Creature) args[0];
                                	Creature defender = (Creature) args[1];
                                	Float armormod = (float) args[5];
                                	 Long starttime = (long) 0;
                                	if (performer instanceof Player && performer.getTemplate().getCreatureAI() == null) {
                                		//if (defender.isUnique()) {
                                			performer.getCommunicator().sendCombatNormalMessage("attacking a unique");
                                			args[13] = true;
                                		//}
                                		damage = Math.floor((double) args[4]); 
                                		Long mdamage =  (long) Math.floor(damage * armormod);
                                		starttime = getTime(performer.getName());
                                		
	                              	      if (starttime != 0){                         
	                                		Connection dbcon10 = null;
	                                		PreparedStatement ps10 = null;	    	
			                      		      try
			                      		      {
			                      			      dbcon10 = ModSupportDb.getModSupportDb();
			                      			      ps10 = dbcon10.prepareStatement("UPDATE DPS "
			                      			      + "SET TotalDamage = TotalDamage + "+mdamage+" WHERE name = \""+performer.getName()+"\"");
			                      			      ps10.executeUpdate();
			                      			      ps10.close(); 
			                      			      dbcon10.close();
				                      		      }
				                      	      catch (SQLException e) {
				                      	          throw new RuntimeException(e);
				                      	        }                              	
			                      		      Long DPS = calcDPS(performer.getName());
	                          
			                      		      performer.getCommunicator().sendCombatNormalMessage("DPS="+DPS+";you did "+mdamage+" damage, which is "+damage+" * "+armormod);
	                              	      	}
                                		}
                                	return method.invoke(proxy, args);
                                };
                            };
                        }
            	});
            }
        	catch (Exception e) {
            throw new HookException(e);
        	} 	
		}

	@Override
	public void onServerStarted() {
		
		 try
		    {
		      Connection con = ModSupportDb.getModSupportDb();
		      String sql = "";
		      
		      if (!ModSupportDb.hasTable(con, "DPS")) {
		        sql = "CREATE TABLE DPS (\t\tname\t\t\t\tVARCHAR(30)\t\t\tNOT NULL DEFAULT 'Unknown',"
		        		+ "\t\tTotalDamage\t\t\t\t\tLONG\t\tNOT NULL DEFAULT 0,"
		        		+ "\t\tStartTime\t\t\t\t\tLONG\t\tNOT NULL DEFAULT 0)";
		        PreparedStatement ps = con.prepareStatement(sql);
		        ps.execute();
		        ps.close();       
		      }
		    }
		    catch (SQLException e)
		    {
		    	throw new RuntimeException(e);
		    }		
	}

	public Long calcDPS(String performer){
		Long DPS = (long) 0;
    	Connection dbcon = null;
	      PreparedStatement ps = null;
	      ResultSet rs = null;
	      try
	      {	      
	      dbcon = ModSupportDb.getModSupportDb();
	      ps = dbcon.prepareStatement("SELECT * FROM DPS WHERE name = \""+performer+"\"");
	      rs = ps.executeQuery();
	      
		Long totaldamage = rs.getLong("TotalDamage");
		Long starttime = rs.getLong("StartTime");
	      rs.close();
	      ps.close();
	      dbcon.close();
	      Long time = (long) (Math.floor((System.currentTimeMillis() - starttime)/1000));
	      if (time == 0)time = (long) 1;
	      DPS = (long) Math.floor(totaldamage / time);
	      return DPS;
	      }
	      catch (SQLException e) {
	          throw new RuntimeException(e);
	        }	
		
		
	}
	
	@Override
	public void configure(Properties arg0) {
		minid = Integer.parseInt(arg0.getProperty("minid", Float.toString(minid)));
		maxid = Integer.parseInt(arg0.getProperty("maxid", Float.toString(maxid)));
		logger.log(Level.INFO, "min: "+minid+" max:"+maxid);
	}

	@Override
	public void init() {
		dpshook();
		deathhook();
	}
	
	public boolean onPlayerMessage(Communicator communicator, String message)
	  {
		if ((message != null) && (message.startsWith("/TEST"))) {
			
			float tester = Server.rand.nextFloat();
			float result =  5.0F + tester * 5.0F;
			communicator.sendNormalServerMessage(" test: "+tester +" result:  "+ result);
			return true;
		}
		
	    if ((message != null) && (message.startsWith("/DPS"))) {
	    	
	    	Long starttime = getTime(communicator.getPlayer().getName());
	    	if (starttime != 0){
	    		//stop dps
	    		communicator.sendNormalServerMessage("Turning off DPS calculations, end DPS:"+calcDPS(communicator.getPlayer().getName()));
	    		resetDPS(communicator.getPlayer().getName());
	    			    	}else{
	    	communicator.sendNormalServerMessage("You did /DPS omg you damage crazy fool, MORE DOTS.");
	    	Connection dbcon10 = null;
		      PreparedStatement ps10 = null;	    	
		      try
		      	{
			      dbcon10 = ModSupportDb.getModSupportDb();
			      ps10 = dbcon10.prepareStatement("UPDATE DPS "
			      + "SET StartTime = "+System.currentTimeMillis()+", TotalDamage = 0 WHERE name = \""+communicator.getPlayer().getName()+"\"");
			      ps10.executeUpdate();
			      ps10.close(); 
			      dbcon10.close();
			      }
		      		catch (SQLException e) {
		      			throw new RuntimeException(e);
		      		}
	    	}
	    	return true;
	    }
	    return false;
	  }
	
	public void resetDPS(String p){
		  Connection dbcon10 = null;
	      PreparedStatement ps10 = null;	    	
	      try
	      {
		      dbcon10 = ModSupportDb.getModSupportDb();
		      ps10 = dbcon10.prepareStatement("UPDATE DPS "
		      + "SET StartTime = 0, TotalDamage = 0 WHERE name = \""+p+"\"");
		      ps10.executeUpdate();
		      ps10.close(); 
		      dbcon10.close();
	      }
	      catch (SQLException e) {
	    	  throw new RuntimeException(e);
	      }			    	
  			
		
	}
	
	public Long getTime(String performer){
		
			Connection dbcon = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			Long starttime = (long) 0;
	      	try
	      		{	      
      	      dbcon = ModSupportDb.getModSupportDb();
      	      ps = dbcon.prepareStatement("SELECT * FROM DPS WHERE name = \""+performer+"\"");
      	      rs = ps.executeQuery();
      	      starttime = rs.getLong("StartTime");
      	      rs.close();
      	      ps.close();
      	      dbcon.close();
      	      }
      	      catch (SQLException e) {
      	          throw new RuntimeException(e);
      	      }			
	      	return starttime;
	}

	public void deathhook(){
		
		try {
            CtClass ctc = HookManager.getInstance().getClassPool().get("com.wurmonline.server.creatures.CreatureStatus");
            ctc.getDeclaredMethod("modifyWounds").instrument(new ExprEditor(){
                 public void edit(MethodCall m) throws CannotCompileException {
                	 if (m.getMethodName().equals("getPower")) {
		                 m.replace("if(this.statusHolder.getPower() >= 3 || (this.statusHolder.getTemplate().getTemplateId() >= "+minid+" && "+maxid+" >= this.statusHolder.getTemplate().getTemplateId())){$_ = 4;};");
		                 return;
                	}
                }
               
            });
        }
        catch (CannotCompileException | NotFoundException e) {
            logger.log(Level.SEVERE, "Failed to apply DPS interception", (Throwable)e);
        }		
		
	}

	public void onPlayerLogin(Player p)
	  	{
		  			boolean founded = false;

			      try
			      {	      
			    	  Connection dbcon = ModSupportDb.getModSupportDb();
			    	  PreparedStatement ps = dbcon.prepareStatement("SELECT * FROM DPS");
			    	  ResultSet rs = ps.executeQuery();
	
			      while (rs.next()) {
			    	  if (rs.getString("name").equals(p.getName())){
			    		  founded = true;
			    	  }		    	  
			      }
			      rs.close();
			      ps.close();
				    }
			      catch (SQLException e) {
			          throw new RuntimeException(e);
			        }
		  
		  
				  if (founded == false){
				    try
					    {
					        Connection dbcon = ModSupportDb.getModSupportDb();
					        PreparedStatement ps = dbcon.prepareStatement("INSERT INTO DPS (name) VALUES(\""+p.getName()+"\")");
						    ps.executeUpdate();
						    ps.close();
				
					    }
					    catch (SQLException e)
					    {
					    	throw new RuntimeException(e);
					    }
				    }else{
				    	//player logged in so reset values.
				    	resetDPS(p.getName());
				    }

	  	}		
}