package org.coldie.wurmunlimited.mods.Dyemaker;



import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.actions.ActionPerformer;
import org.gotti.wurmunlimited.modsupport.actions.BehaviourProvider;
import org.gotti.wurmunlimited.modsupport.actions.ModAction;
import org.gotti.wurmunlimited.modsupport.actions.ModActions;

import com.wurmonline.server.Items;
import com.wurmonline.server.behaviours.Action;
import com.wurmonline.server.behaviours.ActionEntry;
import com.wurmonline.server.creatures.Creature;
import com.wurmonline.server.items.Item;
import com.wurmonline.server.items.ItemTypes;
import com.wurmonline.server.items.WurmColor;
import com.wurmonline.server.players.Player;

import java.util.List;
import java.util.logging.Logger;
import java.util.Arrays;

public class adddye implements WurmServerMod, ItemTypes, ModAction, BehaviourProvider, ActionPerformer {
	static Logger logger = Logger.getLogger(adddye.class.getName());	

	public static short actionId;
	static ActionEntry actionEntry;

	public adddye() {
		actionId = (short) ModActions.getNextActionId();
		actionEntry = ActionEntry.createEntry(actionId, "Add dye", "Adding dye", new int[]{}); 
		ModActions.registerAction(actionEntry);
	}

	@Override
	public BehaviourProvider getBehaviourProvider() {
		return this;
	}

	@Override
	public ActionPerformer getActionPerformer() {
		return this;
	}

	@Override
	public short getActionId() {
		return actionId;
	}
	
	@Override
	public List<ActionEntry> getBehavioursFor(Creature performer, Item source, Item target) {
		if (performer instanceof Player && target.getTemplateId() == Dyemaker.targetid && source.isDye()) {
			return (List<ActionEntry>) Arrays.asList(actionEntry);
		} else {
			return null;
		}
	}
	
	@Override
	public boolean action(Action act, Creature performer, Item source, Item target, short action, float counter) {
		if (performer instanceof Player && target.getTemplateId() == Dyemaker.targetid && source.isDye() ) {

			float sourceql = source.getQualityLevel()/100;
			int redsource = WurmColor.getColorRed(source.getColor());
            int greensource = WurmColor.getColorGreen(source.getColor());
            int bluesource = WurmColor.getColorBlue(source.getColor());
            int volumesource = source.getVolume();
            int newred = (int)((redsource*volumesource/255)*Dyemaker.losspercent*sourceql)/100;
            int newgreen = (int)((greensource*volumesource/255*Dyemaker.losspercent*sourceql)/100);
            int newblue = (int)((bluesource*volumesource/255*Dyemaker.losspercent*sourceql)/100);	

            if(redsource+greensource+bluesource >= Dyemaker.maxrgb) {
            	performer.getCommunicator().sendSafeServerMessage("That dye is to powerful for the device to process, R+G+B must be less than "+Dyemaker.maxrgb);
            	return true;
            }
            if (target.getData1() == -1) {
				Dyemaker.getdata(target);
            }
			target.setAllData(newred+target.getData1(), newgreen+target.getData2(), newblue+target.getExtra1(), 1);
			Items.destroyItem(source.getWurmId());
			performer.getCommunicator().sendSafeServerMessage("You added red:"+(float)newred/1000+
					" green:"+(float)newgreen/1000+" blue:"+(float)newblue/1000);
			return true;
			}
			return false;
		}
}