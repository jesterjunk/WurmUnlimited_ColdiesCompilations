package org.coldie.wurmunlimited.mods.gminvul;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.gotti.wurmunlimited.modloader.classhooks.HookManager;
import org.gotti.wurmunlimited.modloader.interfaces.Initable;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;

import javassist.CannotCompileException;
import javassist.CtClass;
import javassist.NotFoundException;
import javassist.expr.ExprEditor;
import javassist.expr.MethodCall;

public class gminvul implements WurmServerMod, Initable {
	static Logger logger = Logger.getLogger(gminvul.class.getName());
	
	@Override
	public void init() {
	       try {
	            CtClass ctc = HookManager.getInstance().getClassPool().get("com.wurmonline.server.players.Player");
	            ctc.getDeclaredMethod("isInvulnerable").instrument(new ExprEditor(){
	                 public void edit(MethodCall m) throws CannotCompileException {   
	                	 if (m.getMethodName().equals("getPower")) {
	                		 logger.log(Level.INFO, "changing GM invul power from 1 to 3");
			                m.replace("$_ = getPower() - 2;");
			                return;
	                	}
	                }
	            });
	        }
	        catch (CannotCompileException | NotFoundException e) {
	            logger.log(Level.SEVERE, "Failed to apply GM invulnerability interception", (Throwable)e);
	        }
	}
	
}