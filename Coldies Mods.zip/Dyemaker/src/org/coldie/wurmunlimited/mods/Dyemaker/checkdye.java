package org.coldie.wurmunlimited.mods.Dyemaker;



import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.actions.ActionPerformer;
import org.gotti.wurmunlimited.modsupport.actions.BehaviourProvider;
import org.gotti.wurmunlimited.modsupport.actions.ModAction;
import org.gotti.wurmunlimited.modsupport.actions.ModActions;

import com.wurmonline.server.behaviours.Action;
import com.wurmonline.server.behaviours.ActionEntry;
import com.wurmonline.server.creatures.Creature;
import com.wurmonline.server.items.Item;
import com.wurmonline.server.items.ItemTypes;
import com.wurmonline.server.players.Player;

import java.util.List;
import java.util.logging.Logger;
import java.util.Arrays;

public class checkdye implements WurmServerMod, ItemTypes, ModAction, BehaviourProvider, ActionPerformer {
	static Logger logger = Logger.getLogger(checkdye.class.getName());	

	public static short actionId;
	static ActionEntry actionEntry;

	public checkdye() {
		actionId = (short) ModActions.getNextActionId();
		actionEntry = ActionEntry.createEntry(actionId, "Check dye", "Checking dye", new int[]{}); 
		ModActions.registerAction(actionEntry);
	}

	@Override
	public BehaviourProvider getBehaviourProvider() {
		return this;
	}

	@Override
	public ActionPerformer getActionPerformer() {
		return this;
	}

	@Override
	public short getActionId() {
		return actionId;
	}
	
	@Override
	public List<ActionEntry> getBehavioursFor(Creature performer, Item source, Item target) {
		if (performer instanceof Player && target.getTemplateId() == Dyemaker.targetid) {
			return (List<ActionEntry>) Arrays.asList(actionEntry);
		} else {
			return null;
		}
	}
	
	@Override
	public boolean action(Action act, Creature performer, Item source, Item target, short action, float counter) {
		if (performer instanceof Player && target.getTemplateId() == Dyemaker.targetid) {
            

            if (target.getData1() == -1) {
				Dyemaker.getdata(target);
			}
			float red = (float)(target.getData1());
			float green = (float)target.getData2();
			float blue = (float)target.getExtra1();
			performer.getCommunicator().sendSafeServerMessage("Red Volume:"+red/1000);
			performer.getCommunicator().sendSafeServerMessage("Green Volume:"+green/1000);
			performer.getCommunicator().sendSafeServerMessage("Blue Volume:"+blue/1000);
			return true;
		}
		return false;
	}
}