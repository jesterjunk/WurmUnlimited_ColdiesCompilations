package net.coldie.wurmunlimited.mods.eventportals;


import org.gotti.wurmunlimited.modloader.interfaces.Configurable;
import org.gotti.wurmunlimited.modloader.interfaces.Initable;
import org.gotti.wurmunlimited.modloader.interfaces.ItemTemplatesCreatedListener;
import org.gotti.wurmunlimited.modloader.interfaces.PlayerLoginListener;
import org.gotti.wurmunlimited.modloader.interfaces.PreInitable;
import org.gotti.wurmunlimited.modloader.interfaces.ServerStartedListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.actions.ModActions;

import com.wurmonline.server.players.Player;

import org.gotti.wurmunlimited.modsupport.ModSupportDb;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.Logger;


public class eventmod implements WurmServerMod, Configurable, PreInitable, PlayerLoginListener, ServerStartedListener, ItemTemplatesCreatedListener, Initable  {
	static Logger logger = Logger.getLogger(eventmod.class.getName());
    
    public String getVersion() {
        return "v3.0";
    }
   
	public static boolean activated = false;
	public static boolean zennyactivated = false;
	public static HashMap<Integer, Integer> eventlootenable = new HashMap<Integer,Integer>();
	public static final String[] arrevent = new String[0];

	public static int freadeathminx = 0;
	public static int freadeathmaxx = 1;
	public static int freadeathminy = 0;
	public static int freadeathmaxy = 1;
	
	public static boolean active = false;
	
	@Override
	public void onItemTemplatesCreated() {
		new eventitems();
	}

	
	@Override
	public void onServerStarted() {
		ModActions.registerAction(new eventaction());
		ModActions.registerAction(new manageeventaction());
		ModActions.registerAction(new returneventaction());
		ModActions.registerAction(new eventreloadaction());
	    try
	    {
	      Connection con = ModSupportDb.getModSupportDb();
	      String sql = "";
	      
	      if (!ModSupportDb.hasTable(con, "ColdieEventPortals")) {
	        sql = "CREATE TABLE ColdieEventPortals (\t\tid\t\t\t\tLONG\t\t\tNOT NULL UNIQUE,"
	        		+ "\t\tposx\t\t\t\t\tFLOAT\t\tNOT NULL DEFAULT 100,"
	        		+ "\t\tposy\t\t\t\t\tFLOAT\t\tNOT NULL DEFAULT 100,"
	        		+ "\t\tlayer\t\t\t\t\tINT\t\tNOT NULL DEFAULT 0,"
	        		+ "\t\tfloorlevel\t\t\t\t\tINT\t\tNOT NULL DEFAULT 0)";
	        PreparedStatement ps = con.prepareStatement(sql);
	        
	        ps.execute();
	        ps.close();
	        
	        //create first record which will be event location
	        Connection dbcon = ModSupportDb.getModSupportDb();
		    ps = dbcon.prepareStatement("INSERT INTO ColdieEventPortals (id,posx,posy,layer,floorlevel) VALUES(1,1,1,0,0)");
		    ps.executeUpdate();
		    ps.close();	        
	      }
	    }
	    catch (SQLException e)
	    {
	    	throw new RuntimeException(e);
	    }
	    
	    
	}

	@Override
	public void configure(Properties properties) {
		doconfig(properties);
	}
	
	public static void doconfig(Properties properties){				
		freadeathminx = Integer.parseInt(properties.getProperty("freadeathminx", Float.toString(freadeathminx)));
		freadeathmaxx = Integer.parseInt(properties.getProperty("freadeathmaxx", Float.toString(freadeathmaxx)));
		freadeathminy = Integer.parseInt(properties.getProperty("freadeathminy", Float.toString(freadeathminy)));
		freadeathmaxy = Integer.parseInt(properties.getProperty("freadeathmaxy", Float.toString(freadeathmaxy)));
		
	}
	
	
	@Override
	public void preInit() {
		ModActions.init();
	}
	
		@Override
		public void init() {
			freedeathhook.setUpDeathEffectInterception();
		}
		
		//free death check
		public static boolean checkfreedeath(int tilex, int tiley, String name){
	        logger.info("Name: "+name);
			if (tilex > freadeathminx && tilex < freadeathmaxx && tiley > freadeathminy && tiley < freadeathmaxy){
				return true;
			}else{
				return false;
			}
		}


		@Override
		public void onPlayerLogin(Player player) {
			if(active == true) {
				player.getCommunicator().sendNormalServerMessage("Event Portal is active.");
			}
			
		}
}