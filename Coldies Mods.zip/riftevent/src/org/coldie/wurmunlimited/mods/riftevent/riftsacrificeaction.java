package org.coldie.wurmunlimited.mods.riftevent;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.actions.ActionPerformer;
import org.gotti.wurmunlimited.modsupport.actions.BehaviourProvider;
import org.gotti.wurmunlimited.modsupport.actions.ModAction;
import org.gotti.wurmunlimited.modsupport.actions.ModActions;

import com.wurmonline.server.Items;
import com.wurmonline.server.MiscConstants;
import com.wurmonline.server.behaviours.Action;
import com.wurmonline.server.behaviours.ActionEntry;
import com.wurmonline.server.behaviours.MethodsReligion;
import com.wurmonline.server.creatures.Creature;
import com.wurmonline.server.items.Item;
import com.wurmonline.server.items.ItemTypes;
import com.wurmonline.server.players.Player;

public class riftsacrificeaction implements WurmServerMod, ItemTypes, MiscConstants, ModAction, BehaviourProvider, ActionPerformer {
	static Logger logger = Logger.getLogger(riftevent.class.getName());	
	public static short actionId;
	static ActionEntry actionEntry;

	public riftsacrificeaction() {
		actionId = (short) ModActions.getNextActionId();
		actionEntry = ActionEntry.createEntry(actionId, "Sacrifice", "Sacrificing", new int[]{ 
				}); 
		ModActions.registerAction(actionEntry);
	}

	@Override
	public BehaviourProvider getBehaviourProvider() {
		return this;
	}

	@Override
	public ActionPerformer getActionPerformer() {
		return this;
	}

	@Override
	public short getActionId() {
		return actionId;
	}
	
	@Override
	public List<ActionEntry> getBehavioursFor(Creature performer, Item source, Item target) {
		return getBehavioursFor(performer, target);
	}
	
	@Override
	public List<ActionEntry> getBehavioursFor(Creature performer, Item target) {
		if (performer instanceof Player && target.getTemplateId() == riftevent.itemtemplate1) {
				return (List<ActionEntry>) Arrays.asList(actionEntry);
		} else {
			return null;
		}
	}
	
	@Override
	public boolean action(Action act, Creature performer, Item source, Item target, short action, float counter) {
		return action(act, performer, target, action, counter);
	}
	
	@Override
	public boolean action(Action act, Creature performer, Item target, short action, float counter) {
		if(performer instanceof Player && target.getTemplateId() == riftevent.itemtemplate1) {
			doaction(performer, target);
			return true;
		}
		return false;
	}
	
	public void doaction(Creature performer, Item target) {
	      Item[] items = target.getAllItems(false);
	      if (items.length > 0){
	    	int value = 0;
	        for (int x = 0; x < items.length; x++){
	            if (!MethodsReligion.canBeSacrificed(items[x]))
	            {
	              performer.getCommunicator().sendNormalServerMessage("Anubis does not accept " + items[x].getNameWithGenus() + ".");	        
	            }else if (items[x].isBanked()){
	            	performer.getCommunicator().sendNormalServerMessage("Anubis does not accept " + items[x].getNameWithGenus() + ".");
	                      logger.log(Level.INFO, performer.getName() + " tried to sac banked item!");
	            }else if ((!items[x].isPlacedOnParent()) && (!items[x].isInsidePlacedContainer())) {
	            	float newVal = MethodsReligion.getFavorValue(null, items[x]);
	            	float mod = MethodsReligion.getFavorModifier(null, items[x]);
	            	value = (int)(value + Math.max(10.0F, newVal * mod));
	            	Items.destroyItem(items[x].getWurmId());
	            }
	        }
        	performer.getCommunicator().sendNormalServerMessage("Anubis accepts your offering and increases power by "+value);
        	performer.getCommunicator().sendNormalServerMessage("Power needed to spawn are:"+riftevent.lowpowerneeded+":"+riftevent.midpowerneeded+":"+riftevent.highpowerneeded);
	        target.setData2(target.getData2() + value);
	        target.setName("Altar of Anubis: "+target.getData2());
	        target.updateName();
	      }
		
	}
}