package org.coldie.wurmunlimited.mods.deedmaker;



import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.actions.ActionPerformer;
import org.gotti.wurmunlimited.modsupport.actions.BehaviourProvider;
import org.gotti.wurmunlimited.modsupport.actions.ModAction;
import org.gotti.wurmunlimited.modsupport.actions.ModActions;

import com.wurmonline.server.FailedException;
import com.wurmonline.server.NoSuchItemException;
import com.wurmonline.server.NoSuchPlayerException;
import com.wurmonline.server.Server;
import com.wurmonline.server.WurmCalendar;
import com.wurmonline.server.behaviours.Action;
import com.wurmonline.server.behaviours.ActionEntry;
import com.wurmonline.server.creatures.Creature;
import com.wurmonline.server.creatures.NoSuchCreatureException;
import com.wurmonline.server.items.Item;
import com.wurmonline.server.items.ItemTypes;
import com.wurmonline.server.players.Player;
import com.wurmonline.server.villages.NoSuchRoleException;
import com.wurmonline.server.villages.Village;
import com.wurmonline.server.villages.Villages;
import com.wurmonline.server.zones.Zones;

import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.IOException;
import java.util.Arrays;

public class deedmakeraction implements WurmServerMod, ItemTypes, ModAction, BehaviourProvider, ActionPerformer {
	static Logger logger = Logger.getLogger(deedmakeraction.class.getName());	

	public static short actionId;
	static ActionEntry actionEntry;

	public deedmakeraction() {
		actionId = (short) ModActions.getNextActionId();
		actionEntry = ActionEntry.createEntry(actionId, "Make GM Deed", "Making GM Deed", new int[]{}); 
		ModActions.registerAction(actionEntry);
	}

	@Override
	public BehaviourProvider getBehaviourProvider() {
		return this;
	}

	@Override
	public ActionPerformer getActionPerformer() {
		return this;
	}

	@Override
	public short getActionId() {
		return actionId;
	}
	
	@Override
	public List<ActionEntry> getBehavioursFor(Creature performer, Item source, Item target) {
		if (performer instanceof Player && performer.getPower() >= 5 && target.getTemplateId() == 862) {
			return (List<ActionEntry>) Arrays.asList(actionEntry);
		} else {
			return null;
		}
	}
	
	@Override
	public boolean action(Action act, Creature performer, Item source, Item target, short action, float counter) {
		return action(act, performer, target, action, counter);
	}
	
	@Override
	public boolean action(Action act, Creature performer, Item target, short action, float counter) {
		if (performer instanceof Player && performer.getPower() >= 5 && target.getTemplateId() == 862) {
			makedeed(performer, target);
			return true;
		}
		return false;
	}

	private void makedeed(Creature performer, Item target) {
       try {
        	final Random recipeRandom = new Random();
        	int deednum = recipeRandom.nextInt(89);
        	int playerX = (int) (performer.getPosX()/4);
        	int playerY = (int) (performer.getPosY()/4);
            Village v = Villages.createVillage(Zones.safeTileX(playerX - 5), Zones.safeTileX(playerX + 5), Zones.safeTileY(playerY - 5), Zones.safeTileY(playerY + 5), playerX, playerY, "GM Deed " + deednum, performer, target.getWurmId(), true, false, "Loves ya baby", false, (byte)0, 0);
            deedmakeraction.logger.log(Level.INFO, performer.getName() + " founded GM Deed");
            v.addCitizen(performer, v.getRoleForStatus((byte)2));
            Server.getInstance().broadCastSafe(WurmCalendar.getTime(), false);
            Server.getInstance().broadCastSafe("The settlement of GM Deed " + deednum + " has just been founded by " + performer.getName() + ".");
            performer.getCommunicator().sendSafeServerMessage("The settlement of GM Deed " + deednum +" has been founded according to your specifications!");
            v.setIsHighwayAllowed(v.hasHighway());
            v.plan.updateGuardPlan(0, (long)(deedmaker.goldupkeep * 1000000L), 0);
        }
        catch (FailedException fe) {
        	performer.getCommunicator().sendSafeServerMessage(fe.getMessage());
            return;
        }
        catch (NoSuchPlayerException nsp) {
            logger.log(Level.WARNING, "Failed to create settlement: " + nsp.getMessage(), nsp);
            performer.getCommunicator().sendNormalServerMessage("Failed to locate a resource needed for that request. Please contact administration.");
            return;
        }
        catch (NoSuchCreatureException nsc) {
            logger.log(Level.WARNING, "Failed to create settlement: " + nsc.getMessage(), nsc);
            performer.getCommunicator().sendNormalServerMessage("Failed to locate a resource needed for that request. Please contact administration.");
            return;
        }
        catch (IOException iox) {
            logger.log(Level.WARNING, "Failed to create settlement:" + iox.getMessage(), iox);
            performer.getCommunicator().sendNormalServerMessage("Failed to locate a resource needed for that request. Please contact administration.");
            return;
        }
        catch (NoSuchRoleException nsr) {
            logger.log(Level.WARNING, "Failed to create settlement:" + nsr.getMessage(), nsr);
            performer.getCommunicator().sendNormalServerMessage("Failed to locate a role needed for that request. Please contact administration.");
            return;
        }
        catch (NoSuchItemException nsi) {
            logger.log(Level.WARNING, "Failed to create settlement:" + nsi.getMessage(), nsi);
            performer.getCommunicator().sendNormalServerMessage("Failed to located the deed. The operation was aborted.");
            return;
        }
		
	}
	
}