package org.coldie.wurmunlimited.mods.Dyemaker;



import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.actions.ActionPerformer;
import org.gotti.wurmunlimited.modsupport.actions.BehaviourProvider;
import org.gotti.wurmunlimited.modsupport.actions.ModAction;
import org.gotti.wurmunlimited.modsupport.actions.ModActions;

import com.wurmonline.server.MiscConstants;
import com.wurmonline.server.behaviours.Action;
import com.wurmonline.server.behaviours.ActionEntry;
import com.wurmonline.server.behaviours.MethodsItems;
import com.wurmonline.server.creatures.Creature;
import com.wurmonline.server.items.Item;
import com.wurmonline.server.items.ItemTypes;
import com.wurmonline.server.players.Player;
import com.wurmonline.server.questions.extractdyequestion;

import java.util.List;
import java.util.logging.Logger;
import java.util.Arrays;

public class removedye implements WurmServerMod, ItemTypes, MiscConstants, ModAction, BehaviourProvider, ActionPerformer {
	static Logger logger = Logger.getLogger(removedye.class.getName());	

	public static short actionId;
	static ActionEntry actionEntry;

	public removedye() {
		actionId = (short) ModActions.getNextActionId();
		actionEntry = ActionEntry.createEntry(actionId, "Extract dye", "Extracting dye", new int[]{}); 
		ModActions.registerAction(actionEntry);
	}

	@Override
	public BehaviourProvider getBehaviourProvider() {
		return this;
	}

	@Override
	public ActionPerformer getActionPerformer() {
		return this;
	}

	@Override
	public short getActionId() {
		return actionId;
	}
	
	@Override
	public List<ActionEntry> getBehavioursFor(Creature performer, Item source, Item target) {
		if (performer instanceof Player && target.getTemplateId() == Dyemaker.targetid && source.isContainerLiquid() &&
				!MethodsItems.checkIfStealing(target, performer, null) && target.mayAccessHold(performer)) {
			return (List<ActionEntry>) Arrays.asList(actionEntry);
		} else {
			return null;
		}
	}
	
	@Override
	public boolean action(Action act, Creature performer, Item source, Item target, short action, float counter) {
		if (performer instanceof Player && target.getTemplateId() == Dyemaker.targetid && source.isContainerLiquid() &&
				!MethodsItems.checkIfStealing(target, performer, null) && target.mayAccessHold(performer)) {
			if(!source.isEmpty(true)) {
				performer.getCommunicator().sendSafeServerMessage("Container needs to be completely empty.");
				return true;
			}

            if (target.getData1() == -1) {
				Dyemaker.getdata(target);
			}
			try {
				extractdyequestion aq = new extractdyequestion(
		                performer, 
		                "Extract Dye", 
		                "What dye combination would you like to Extract??\n\n", 
		                performer.getWurmId());
		              	
						Dyemaker.act = act;
						Dyemaker.performer = performer; 
						Dyemaker.source = source;
						Dyemaker.item = target;
		              aq.sendQuestion();
				return true;
			} catch (Exception e) {
				return false;
			}			
			
		}
		return false;
	}


}