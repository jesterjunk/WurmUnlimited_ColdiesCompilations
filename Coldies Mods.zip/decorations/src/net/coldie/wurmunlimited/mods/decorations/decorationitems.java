package net.coldie.wurmunlimited.mods.decorations;

import java.io.IOException;

import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;

import com.wurmonline.server.MiscConstants;
import com.wurmonline.server.items.AdvancedCreationEntry;
import com.wurmonline.server.items.CreationCategories;
import com.wurmonline.server.items.CreationEntryCreator;
import com.wurmonline.server.items.CreationRequirement;
import com.wurmonline.server.items.ItemList;
import com.wurmonline.server.items.ItemTypes;
import com.wurmonline.server.skills.SkillList;

public class decorationitems implements WurmServerMod, ItemTypes, MiscConstants {
	
	public decorationitems() {
		
		//cotton
			
			//teddy bear
			try {
	
				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 1, "Teddybear", "Teddybears", "superb", "good", "ok", "poor",
						"Something to cuddle and make you feel good.",
						new short[] { ITEM_TYPE_CLOTH, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION },
						(short)306, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.teddybear.", 30.0F, 1, (byte)17, 10000, true).setContainerSize(50, 50, 50);
			}catch(IOException e){
				
			}
	        AdvancedCreationEntry teddy = CreationEntryCreator.createAdvancedEntry(SkillList.CLOTHTAILORING, ItemList.needleIron, ItemList.clothString, decorations.startid + 1, false, true, 0.0f, false, false, CreationCategories.TOYS);
	        teddy.addRequirement(new CreationRequirement(1, ItemList.clothYard, 5, true));
	        teddy.addRequirement(new CreationRequirement(2, ItemList.cotton, 5, true));
	        teddy.addRequirement(new CreationRequirement(3, ItemList.charcoal, 3, true));
	        
	  
	        
			//bunny
			try {
	
				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 2, "Bunny", "Bunnies", "superb", "good", "ok", "poor",
						"Something to cuddle and make you feel good.",
						new short[] { ITEM_TYPE_CLOTH, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION},
						(short)306, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.bunny.", 30.0F, 1, (byte)17, 10000, true);
			}catch(IOException e){
				
			}
	        AdvancedCreationEntry bunny = CreationEntryCreator.createAdvancedEntry(SkillList.CLOTHTAILORING, ItemList.needleIron, ItemList.clothString, decorations.startid + 2, false, true, 0.0f, false, false, CreationCategories.TOYS);
	        bunny.addRequirement(new CreationRequirement(1, ItemList.clothYard, 5, true));
	        bunny.addRequirement(new CreationRequirement(2, ItemList.cotton, 5, true));
	        bunny.addRequirement(new CreationRequirement(3, ItemList.charcoal, 3, true));
	       
			//koala
			try {
	
				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 3, "Koala", "Koalas", "superb", "good", "ok", "poor",
						"Something to cuddle and make you feel good.",
						new short[] { ITEM_TYPE_CLOTH, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION },
						(short)306, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.koala.", 30.0F, 1, (byte)17, 10000, true);
			}catch(IOException e){
				
			}
	        AdvancedCreationEntry koala = CreationEntryCreator.createAdvancedEntry(SkillList.CLOTHTAILORING, ItemList.needleIron, ItemList.clothString, decorations.startid + 3, false, true, 0.0f, false, false, CreationCategories.TOYS);
	        koala.addRequirement(new CreationRequirement(1, ItemList.clothYard, 5, true));
	        koala.addRequirement(new CreationRequirement(2, ItemList.cotton, 5, true));
	        koala.addRequirement(new CreationRequirement(3, ItemList.charcoal, 3, true));
	        
        //end cotton

        //wood
			//rocking horse
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 4, "Rocking horse", "Rocking horse", "superb", "good", "ok", "poor",
						"A wooden horse for a child to ride.",
						new short[] { ITEM_TYPE_WOOD, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE, ITEM_TYPE_SUPPORTS_SECONDARY_COLOR, ITEM_TYPE_HOLLOW, ITEM_TYPE_VIEWABLE_SUBITEMS },
						(short)0, (short)1, 0, 9072000L, 150, 150, 150, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.rockinghorse.", 30.0F, 500, (byte)14, 10000, true).setSecondryItem("Seat and feet").setContainerSize(50, 50, 50);
			}catch(IOException e){
				
			}
	        AdvancedCreationEntry horse = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.hammerWood, ItemList.plank, decorations.startid + 4, false, true, 0.0f, false, false, CreationCategories.TOYS);
	        horse.addRequirement(new CreationRequirement(1, ItemList.shaft, 5, true));
	        horse.addRequirement(new CreationRequirement(2, ItemList.nailsIronSmall, 10, true));
	        
	        //bowling
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 5, "Bowling set", "Bowling sets", "superb", "good", "ok", "poor",
						"A game played by children.",
						new short[] { ITEM_TYPE_WOOD, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.bowling.", 30.0F, 1, (byte)14, 10000, true);
			}catch(IOException e){
				
			}
	        @SuppressWarnings("unused")
			AdvancedCreationEntry bowling = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.knifeCarving, ItemList.log, decorations.startid + 5, false, true, 0.0f, false, false, CreationCategories.TOYS);
       
	        //dragon box
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 6, "Block set with dragon image", "Block sets with dragon image", "superb", "good", "ok", "poor",
						"A puzzle game",
						new short[] { ITEM_TYPE_WOOD, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION},
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.dragonbox.", 30.0F, 1, (byte)14, 10000, true);
			}catch(IOException e){
				
			}
	        AdvancedCreationEntry dragonbox = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.knifeCarving, ItemList.plank, decorations.startid + 6, false, true, 0.0f, false, false, CreationCategories.TOYS);
	        dragonbox.addRequirement(new CreationRequirement(1, ItemList.shaft, 3, true));
	        dragonbox.addRequirement(new CreationRequirement(2, ItemList.dye, 1, true));
        
        
	        //lute
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 7, "Lute", "Lutes", "superb", "good", "ok", "poor",
						"A puzzle game",
						new short[] { ITEM_TYPE_WOOD, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.lute.", 30.0F, 1, (byte)14, 1000, true);
			}catch(IOException e){
				
			}
	        AdvancedCreationEntry lute = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.knifeCarving, ItemList.plank, decorations.startid + 7, false, true, 0.0f, false, false, CreationCategories.TOYS);
	        lute.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
	        lute.addRequirement(new CreationRequirement(2, ItemList.metalWires, 6, true));

	        
	        //bilboquet
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 8, "Bilboquet", "Bilboquets", "superb", "good", "ok", "poor",
						"A game played by children.",
						new short[] { ITEM_TYPE_WOOD, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.bilboquet.", 30.0F, 1, (byte)14, 10000, true);
			}catch(IOException e){
				
			}

			AdvancedCreationEntry bilboquet = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.knifeCarving, ItemList.log, decorations.startid + 8, false, true, 0.0f, false, false, CreationCategories.TOYS);
			bilboquet.addRequirement(new CreationRequirement(1, ItemList.clothString, 1, true));

        //end wood
			
		//metal
			//leaning axe
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 9, "Leaning Axe", "Leaning Axes", "superb", "good", "ok", "poor",
						"Axe that leans.",
						new short[] { ITEM_TYPE_METAL, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.leaningaxe.", 30.0F, 1, (byte)14, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry leaningaxe = CreationEntryCreator.createAdvancedEntry(SkillList.GROUP_SMITHING_WEAPONSMITHING, ItemList.shaft, ItemList.axeHeadMedium, decorations.startid + 9, true, true, 0.0f, false, false, CreationCategories.TOYS);

			
		//end metal
			
		//clay
			//ducky
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 10, "Duck", "Ducks", "superb", "good", "ok", "poor",
						"A duck decoration.",
						new short[] { ITEM_TYPE_POTTERY, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.duck.", 30.0F, 1, (byte)19, 10000, true).setContainerSize(1, 1, 1);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry duck = CreationEntryCreator.createAdvancedEntry(SkillList.POTTERY, ItemList.bodyHand, ItemList.clay, decorations.startid + 10, false, true, 0.0f, false, false, CreationCategories.TOYS);
			
			//marbles
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 11, "Marbles", "Marbles", "superb", "good", "ok", "poor",
						"Bag of marbles.",
						new short[] { ITEM_TYPE_POTTERY, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.marbles.", 30.0F, 1, (byte)19, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry marbles = CreationEntryCreator.createAdvancedEntry(SkillList.POTTERY, ItemList.bodyHand, ItemList.clay, decorations.startid + 11, false, true, 0.0f, false, false, CreationCategories.TOYS);
		//end clay
			
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 12, "Chess Table", "Chess Tables", "superb", "good", "ok", "poor",
						"A table design for playing chess on.",
						new short[] { ITEM_TYPE_WOOD, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE, ITEM_TYPE_HOLLOW, ITEM_TYPE_VIEWABLE_SUBITEMS },
						(short)60, (short)1, 0, 9072000L, 400, 400, 400, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.furniture.chesstable.", 30.0F, 5000, (byte)14, 10000, true).setContainerSize(400, 400, 400);
			}catch(IOException e){
				
			}

			AdvancedCreationEntry ChessTable = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.knifeCarving, ItemList.plank, decorations.startid + 12, false, true, 0.0f, false, false, CreationCategories.FURNITURE);
	        ChessTable.addRequirement(new CreationRequirement(1, ItemList.shaft, 4, true));
	        ChessTable.addRequirement(new CreationRequirement(2, ItemList.plank, 4, true));
	        
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 13, "Chess Chair", "Chess Chairs", "superb", "good", "ok", "poor",
						"A decorative chair designed to match the Chess Table.",
						new short[] { 108, 21, 135, 86, 51, 52, 44, 117, 197, 199, 48 },
						(short)274, (short)41, 0, 9072000L, 150, 150, 150, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.furniture.chair.chesschair.", 30.0F, 500, (byte)14, 10000, true);
			}catch(IOException e){
				
			}

			AdvancedCreationEntry ChessChair = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.knifeCarving, ItemList.plank, decorations.startid + 13, false, true, 0.0f, false, false, CreationCategories.FURNITURE);
			ChessChair.addRequirement(new CreationRequirement(1, ItemList.shaft, 4, true));
			ChessChair.addRequirement(new CreationRequirement(2, ItemList.plank, 4, true));	
			
			
			
			
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 14, "Chess White Pawn", "Chess White Pawns", "superb", "good", "ok", "poor",
						"A chess peice used in playing a strategy game.",
						new short[] { ITEM_TYPE_STONE, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.chesswhitepawn.", 30.0F, 1, (byte)62, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry Chesswhitepawn = CreationEntryCreator.createAdvancedEntry(SkillList.STONECUTTING, ItemList.stoneChisel, ItemList.marbleShard, decorations.startid + 14, false, true, 0.0f, false, false, CreationCategories.TOYS);
			
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 15, "Chess White Horse", "Chess White Horses", "superb", "good", "ok", "poor",
						"A chess peice used in playing a strategy game.",
						new short[] { ITEM_TYPE_STONE, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.chesswhitehorse.", 30.0F, 1, (byte)62, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry Chesswhitehorse = CreationEntryCreator.createAdvancedEntry(SkillList.STONECUTTING, ItemList.stoneChisel, ItemList.marbleShard, decorations.startid + 15, false, true, 0.0f, false, false, CreationCategories.TOYS);
			
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 16, "Chess White Castle", "Chess White Castles", "superb", "good", "ok", "poor",
						"A chess peice used in playing a strategy game.",
						new short[] { ITEM_TYPE_STONE, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.chesswhitecastle.", 30.0F, 1, (byte)62, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry Chesswhitecastle = CreationEntryCreator.createAdvancedEntry(SkillList.STONECUTTING, ItemList.stoneChisel, ItemList.marbleShard, decorations.startid + 16, false, true, 0.0f, false, false, CreationCategories.TOYS);
	
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 17, "Chess White Bishop", "Chess White Bishops", "superb", "good", "ok", "poor",
						"A chess peice used in playing a strategy game.",
						new short[] { ITEM_TYPE_STONE, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.chesswhitebishop.", 30.0F, 1, (byte)62, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry Chesswhitebishop = CreationEntryCreator.createAdvancedEntry(SkillList.STONECUTTING, ItemList.stoneChisel, ItemList.marbleShard, decorations.startid + 17, false, true, 0.0f, false, false, CreationCategories.TOYS);
			
			
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 18, "Chess White King", "Chess White Kings", "superb", "good", "ok", "poor",
						"A chess peice used in playing a strategy game.",
						new short[] { ITEM_TYPE_STONE, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.chesswhiteking.", 30.0F, 1, (byte)62, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry Chesswhiteking = CreationEntryCreator.createAdvancedEntry(SkillList.STONECUTTING, ItemList.stoneChisel, ItemList.marbleShard, decorations.startid + 18, false, true, 0.0f, false, false, CreationCategories.TOYS);
			
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 19, "Chess White Queen", "Chess White Queens", "superb", "good", "ok", "poor",
						"A chess peice used in playing a strategy game.",
						new short[] { ITEM_TYPE_STONE, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.chesswhitequeen.", 30.0F, 1, (byte)62, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry Chesswhitequeen = CreationEntryCreator.createAdvancedEntry(SkillList.STONECUTTING, ItemList.stoneChisel, ItemList.marbleShard, decorations.startid + 19, false, true, 0.0f, false, false, CreationCategories.TOYS);

			
			
			
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 20, "Chess Black Pawn", "Chess Black Pawns", "superb", "good", "ok", "poor",
						"A chess peice used in playing a strategy game.",
						new short[] { ITEM_TYPE_STONE, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.chessblackpawn.", 30.0F, 1, (byte)61, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry Chessblackpawn = CreationEntryCreator.createAdvancedEntry(SkillList.STONECUTTING, ItemList.stoneChisel, ItemList.slateShard, decorations.startid + 20, false, true, 0.0f, false, false, CreationCategories.TOYS);
			
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 21, "Chess Black Horse", "Chess Black Horses", "superb", "good", "ok", "poor",
						"A chess peice used in playing a strategy game.",
						new short[] { ITEM_TYPE_STONE, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.chessblackhorse.", 30.0F, 1, (byte)61, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry Chessblackhorse = CreationEntryCreator.createAdvancedEntry(SkillList.STONECUTTING, ItemList.stoneChisel, ItemList.slateShard, decorations.startid + 21, false, true, 0.0f, false, false, CreationCategories.TOYS);
			
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 23, "Chess Black Castle", "Chess Black Castles", "superb", "good", "ok", "poor",
						"A chess peice used in playing a strategy game.",
						new short[] { ITEM_TYPE_STONE, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.chessblackcastle.", 30.0F, 1, (byte)61, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry Chessblackcastle = CreationEntryCreator.createAdvancedEntry(SkillList.STONECUTTING, ItemList.stoneChisel, ItemList.slateShard, decorations.startid + 23, false, true, 0.0f, false, false, CreationCategories.TOYS);
	
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 24, "Chess Black Bishop", "Chess Black Bishops", "superb", "good", "ok", "poor",
						"A chess peice used in playing a strategy game.",
						new short[] { ITEM_TYPE_STONE, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.chessblackbishop.", 30.0F, 1, (byte)61, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry Chessblackbishop = CreationEntryCreator.createAdvancedEntry(SkillList.STONECUTTING, ItemList.stoneChisel, ItemList.slateShard, decorations.startid + 24, false, true, 0.0f, false, false, CreationCategories.TOYS);
			
			
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 25, "Chess Black King", "Chess Black Kings", "superb", "good", "ok", "poor",
						"A chess peice used in playing a strategy game.",
						new short[] { ITEM_TYPE_STONE, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.chessblackking.", 30.0F, 1, (byte)61, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry Chessblackking = CreationEntryCreator.createAdvancedEntry(SkillList.STONECUTTING, ItemList.stoneChisel, ItemList.slateShard, decorations.startid + 25, false, true, 0.0f, false, false, CreationCategories.TOYS);
			
			try {

				com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(decorations.startid + 26, "Chess Black Queen", "Chess Black Queens", "superb", "good", "ok", "poor",
						"A chess peice used in playing a strategy game.",
						new short[] { ITEM_TYPE_STONE, ITEM_TYPE_REPAIRABLE, ITEM_TYPE_NOT_MISSION, ITEM_TYPE_DECORATION, ITEM_TYPE_COLORABLE },
						(short)0, (short)1, 0, 9072000L, 1, 1, 1, -10,
						MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, "model.toy.chessblackqueen.", 30.0F, 1, (byte)61, 10000, true);
			}catch(IOException e){
				
			}

			@SuppressWarnings("unused")
			AdvancedCreationEntry Chessblackqueen = CreationEntryCreator.createAdvancedEntry(SkillList.STONECUTTING, ItemList.stoneChisel, ItemList.slateShard, decorations.startid + 26, false, true, 0.0f, false, false, CreationCategories.TOYS);
			
			
			
			
	}
}