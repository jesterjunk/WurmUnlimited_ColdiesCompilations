package com.wurmonline.server.questions;

import com.wurmonline.server.Items;
import com.wurmonline.server.NoSuchItemException;
import com.wurmonline.server.creatures.Creature;
import com.wurmonline.server.items.Item;
import com.wurmonline.server.zones.VolaTile;
import com.wurmonline.server.zones.Zones;

import java.util.Properties;

import net.coldie.tools.BmlForm;

import org.coldie.wurmunlimited.mods.paintings.paintings;


public class changelandscapequestion extends Question
{
	  private boolean properlySent = false;
	  int currentpage = 1;
	  Creature performer;
	  long target;
	  changelandscapequestion(Creature aResponder, String aTitle, String aQuestion, int aType, long aTarget)
	  {
	    super(aResponder, aTitle, aQuestion, aType, aTarget);
	  }
	  
	  public changelandscapequestion(Creature aResponder, String aTitle, String aQuestion, long aTarget, int page)
	  {
	    super(aResponder, aTitle, aQuestion, 79, aTarget);
	    currentpage = page;
	    performer = aResponder;
	    target = aTarget;
	    
	  }	
	  
	  int getnextimagenumber(int current){
		  if (current > paintings.landscapenumber) {current=1;}
		  return current;
	  }

	  int getpreviousimagenumber(int current){
		  if (current < 1) {current=paintings.landscapenumber;}
		  return current;
	  }	  
	  
	  Item item = null;
	  public void answer(Properties answer)
	  {
	    if (!properlySent) {
	      return;
	    }
	    
	    // check drop down and accepted
	    boolean accepted = (answer.containsKey("accept")) && (answer.get("accept") == "true");
	    boolean previous = (answer.containsKey("previous")) && (answer.get("previous") == "true");
	    boolean next = (answer.containsKey("next")) && (answer.get("next") == "true");

	    if (accepted)
	    {
	        VolaTile vt = Zones.getOrCreateTile(item.getTilePos(), item.isOnSurface());
	        vt.makeInvisible(item);
	        item.setData1(currentpage);
	        vt.makeVisible(item);			
	    }else if(previous) {
	    	currentpage = getpreviousimagenumber(currentpage-1);
			try {
				changelandscapequestion aq = new changelandscapequestion(
						performer,
		                "Change Image",
		                "Which image would you like to use?",
		                target,currentpage);
		              
		              aq.sendQuestion();
			} catch (Exception e) {
				e.printStackTrace();
			}	    	
	    }else if(next) {
	    	currentpage = getnextimagenumber(currentpage+1);
			try {
				changelandscapequestion aq = new changelandscapequestion(
						performer,
		                "Change Image",
		                "Which image would you like to use?",
		                target,currentpage);
		              aq.sendQuestion();
			} catch (Exception e) {
				e.printStackTrace();
			}	    	
	    }
	    
	  }

	  public void sendQuestion()
	  {
	    boolean ok = true;
	      
	    if (ok) {
	      properlySent = true;
			try {
				item = Items.getItem(getTarget());
			} catch (NoSuchItemException | NumberFormatException e) {
				e.printStackTrace();
			}
			
	      BmlForm f = new BmlForm("");
	      f.addHidden("id", id+"");
	      f.addBoldText("                                                    "+getQuestion(), new String[0]);
	      f.addText("\n ", new String[0]);
	      f.addText("                                                            This is image number "+currentpage+" out of "+paintings.landscapenumber,  new String[0]);
	      f.addRaw("table{rows='1';cols='2';");
	      f.addRaw("text{text=' '};");
	      f.addRaw("image{src='img.framedlandscape."+currentpage+"';size='400,260'}}");

	      
//stop here
	      f.addText("\n ", new String[0]);
	      f.addRaw("table{rows='1';cols='6';");
	      f.addRaw("text{text='                       '};");
	      f.addRaw("button{text='<- Image "+getpreviousimagenumber(currentpage-1)+"';id='previous'};");
	      f.addRaw("text{text=''};");
	 	  f.addRaw("button{text='Choose Image';id='accept'};");
	 	  f.addRaw("text{text=''};");
	 	  f.addRaw("button{text='Image "+getnextimagenumber(currentpage+1)+" ->';id='next'};");
	      f.addRaw("}");
	      
	      getResponder().getCommunicator().sendBml(
	        540, 
	        500, 
	        true, 
	        true, 
	        f.toString(), 
	        200, 
	        200, 
	        200, 
	        title);
	    }
	  }

}