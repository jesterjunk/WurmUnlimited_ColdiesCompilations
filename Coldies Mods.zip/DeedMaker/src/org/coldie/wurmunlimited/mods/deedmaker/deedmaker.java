package org.coldie.wurmunlimited.mods.deedmaker;

import java.util.Properties;
import org.gotti.wurmunlimited.modloader.interfaces.Configurable;
import org.gotti.wurmunlimited.modloader.interfaces.ItemTemplatesCreatedListener;
import org.gotti.wurmunlimited.modloader.interfaces.ServerStartedListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.actions.ModActions;


public class deedmaker implements WurmServerMod, Configurable, ServerStartedListener, ItemTemplatesCreatedListener {
	static float goldupkeep = 1.0f;
	static int InvitorID = 131322;
	public static String InvitorModel = "model.creature.humanoid.human.guard.male";
	
	
    public String getVersion() {
        return "v4.1";
    }
   	
	@Override
	public void configure(Properties properties) {
		InvitorModel = properties.getProperty("InvitorModel",InvitorModel);
		InvitorID = Integer.parseInt(properties.getProperty("InvitorID", Float.toString(InvitorID)));
		doconfig(properties);
	}
	
	public static void doconfig(Properties properties){	
		goldupkeep = Float.parseFloat(properties.getProperty("goldupkeep", Float.toString(goldupkeep)));
	}
	
	public void onItemTemplatesCreated() {
		new deedmakeritems();
	}	
	
	@Override
	public void onServerStarted() {
		ModActions.registerAction(new deedmakeraction());
		ModActions.registerAction(new changemayor());
		ModActions.registerAction(new joindeedaction());
	}
}
