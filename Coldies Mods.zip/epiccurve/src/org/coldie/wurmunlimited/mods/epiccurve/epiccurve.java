package org.coldie.wurmunlimited.mods.epiccurve;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.gotti.wurmunlimited.modloader.classhooks.HookException;
import org.gotti.wurmunlimited.modloader.classhooks.HookManager;
import org.gotti.wurmunlimited.modloader.interfaces.Initable;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtConstructor;
import javassist.NotFoundException;
import javassist.expr.ExprEditor;
import javassist.expr.FieldAccess;


public class epiccurve implements WurmServerMod, Initable {
	static Logger logger = Logger.getLogger(epiccurve.class.getName());	
    
    public String getVersion() {
        return "v3.0";
    }
   
@Override
public void init() {
	ClassPool classPool = HookManager.getInstance().getClassPool();
	enableEpicCurve(classPool);

}

private void enableEpicCurve(ClassPool cp) {
        try {
            CtClass c = cp.get("com.wurmonline.server.skills.Skill");
            CtConstructor ctor = c.getClassInitializer();
            ctor.instrument(new ExprEditor(){

                public void edit(FieldAccess m) throws CannotCompileException {
                    if (m.getClassName().equals("com.wurmonline.server.ServerEntry") && m.getFieldName().equals("EPIC")) {
                        logger.log(Level.WARNING, "Epic 1: modified skillMod");
                        m.replace("$_ = true;");
                    }
                }
            });
            
            c = cp.get("com.wurmonline.server.Server");
            c.getDeclaredMethods("getModifiedFloatEffect")[0].instrument(new ExprEditor(){

                public void edit(FieldAccess m) throws CannotCompileException {
                    if (m.getFieldName().equals("EpicServer")) {
                        logger.log(Level.WARNING, "Epic 3: modified float effect enabled (curve)");
                        m.replace("$_ = true;");
                    }
                }
            });
            c.getDeclaredMethods("getModifiedPercentageEffect")[0].instrument(new ExprEditor(){

                public void edit(FieldAccess m) throws CannotCompileException {
                    if (m.getFieldName().equals("EpicServer")) {
                        logger.log(Level.WARNING, "Epic 4: modified percentage effect enabled (curve)");
                        m.replace("$_ = true;");
                    }
                }
            });

        }
        catch (CannotCompileException | NotFoundException e) {
            throw new HookException((Throwable)e);
        }
        logger.log(Level.WARNING, "Epic 5: done modifying Epic concept");
    }
}