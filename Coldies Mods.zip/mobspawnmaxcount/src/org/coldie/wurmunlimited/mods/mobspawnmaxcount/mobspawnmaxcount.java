package org.coldie.wurmunlimited.mods.mobspawnmaxcount;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.gotti.wurmunlimited.modloader.ReflectionUtil;
import org.gotti.wurmunlimited.modloader.interfaces.Configurable;
import org.gotti.wurmunlimited.modloader.interfaces.ServerStartedListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;

import com.wurmonline.server.creatures.CreatureTemplate;
import com.wurmonline.server.creatures.CreatureTemplateFactory;
import com.wurmonline.server.creatures.NoSuchCreatureTemplateException;

public class mobspawnmaxcount implements WurmServerMod, ServerStartedListener, Configurable {
	static Logger logger = Logger.getLogger(mobspawnmaxcount.class.getName());
	public static String mobmaxes = "";
	
	@Override
	public void onServerStarted() {
		try {
			changemax();
		} catch (NoSuchCreatureTemplateException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassCastException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		}
	}
	
	static public void changemax() throws NoSuchCreatureTemplateException, IllegalArgumentException, IllegalAccessException, ClassCastException, NoSuchFieldException {
		logger.log(Level.INFO, "Creature max changes");
		String[] mobmaxesstring = mobmaxes.split(";");
		for(int x=0;x < mobmaxesstring.length;x++) {
			String[] mobsmaxesstring = mobmaxesstring[x].split(",");
			try {
				logger.log(Level.INFO, "mob id: "+ mobsmaxesstring[0]);
				ReflectionUtil.setPrivateField(CreatureTemplateFactory.getInstance().getTemplate(Integer.parseInt(mobsmaxesstring[0])),
				ReflectionUtil.getField(CreatureTemplate.class, "maxPopulationOfCreatures"), Integer.parseInt(mobsmaxesstring[1]));
				ReflectionUtil.setPrivateField(CreatureTemplateFactory.getInstance().getTemplate(Integer.parseInt(mobsmaxesstring[0])),
				ReflectionUtil.getField(CreatureTemplate.class, "usesMaxPopulation"), true);
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
	}

	@Override
	public void configure(Properties properties) {
		mobmaxes = properties.getProperty("mobmaxes",mobmaxes);
	}
}