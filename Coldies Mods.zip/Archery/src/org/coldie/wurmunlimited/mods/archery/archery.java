package org.coldie.wurmunlimited.mods.archery;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.gotti.wurmunlimited.modloader.classhooks.HookException;
import org.gotti.wurmunlimited.modloader.classhooks.HookManager;
import org.gotti.wurmunlimited.modloader.classhooks.InvocationHandlerFactory;
import org.gotti.wurmunlimited.modloader.interfaces.Configurable;
import org.gotti.wurmunlimited.modloader.interfaces.Initable;
import org.gotti.wurmunlimited.modloader.interfaces.ServerStartedListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.actions.ModActions;

import com.wurmonline.server.Items;
import com.wurmonline.server.creatures.Creature;
import com.wurmonline.server.items.Item;
import com.wurmonline.server.items.ItemFactory;


import javassist.CtClass;
import javassist.CtPrimitiveType;
import javassist.bytecode.Descriptor;
import javassist.ClassPool;

public class archery implements WurmServerMod, Configurable, ServerStartedListener, Initable  {
	static Logger logger = Logger.getLogger(archery.class.getName());	
	
	public static float uniquefactor = 1.0f;
	public static float damagefactor = 1.0f;
	public static float firingspeedadjustment = 2;
    public String getVersion() {
        return "v2.0";
    }
    
    
	@Override
	public void onServerStarted() {
		
		ModActions.registerAction(new archeryloreaction());
	       try {
	    	   ClassPool classPool = HookManager.getInstance().getClassPool();
	            String descriptor = Descriptor.ofMethod(CtPrimitiveType.booleanType, new CtClass[] {
	            		classPool.get("com.wurmonline.server.creatures.Creature"), 
	            		classPool.get("com.wurmonline.server.creatures.Creature"), 
	            		classPool.get("com.wurmonline.server.items.Item"), 
	            		CtPrimitiveType.floatType,
	            		classPool.get("com.wurmonline.server.behaviours.Action")
	            		});
	               HookManager.getInstance().registerHook("com.wurmonline.server.combat.Archery", "attack", descriptor, new InvocationHandlerFactory(){
	 
	            	@Override 
	                        public InvocationHandler createInvocationHandler(){
	                            return new InvocationHandler(){
	                                @Override
	                                public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
	                                	float count = (float)args[3]; 
	                                	if (count != 1.0) args[3] = (float)args[3] * firingspeedadjustment;
	                                    return method.invoke(proxy, args);
	                                };
	                            };
	                        }
	            	});
	            }
	        	catch (Exception e) {
	            throw new HookException(e);
	        	}		
	}

	@Override
	public void configure(Properties properties) {
		damagefactor = Float.valueOf(properties.getProperty("damagefactor", String.valueOf(damagefactor))); 
		uniquefactor = Float.valueOf(properties.getProperty("uniquefactor", String.valueOf(uniquefactor))); 
		firingspeedadjustment = Float.valueOf(properties.getProperty("firingspeedadjustment", String.valueOf(firingspeedadjustment)));
	}
	
	@Override
	public void init() {
		
       try {

           String descriptor = Descriptor.ofMethod(HookManager.getInstance().getClassPool().get("com.wurmonline.server.items.Item"), new CtClass[] {
                   HookManager.getInstance().getClassPool().get("com.wurmonline.server.creatures.Creature")});       	
              HookManager.getInstance().registerHook("com.wurmonline.server.combat.Archery", "getArrow", descriptor, new InvocationHandlerFactory(){

           	@Override 
                       public InvocationHandler createInvocationHandler(){
                           return new InvocationHandler(){

                               @Override
                               public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                                   Creature performer = (Creature) args[0];
                                   Item arrow = null; 
                                   Item[] inventoryItems = performer.getInventory().getAllItems(false);
                                   for (int x = 0; x < inventoryItems.length; x++)
                                   {
                                     if (inventoryItems[x].getTemplateId() == 462) {
                                         arrow = inventoryItems[x].findFirstContainedItem(456);
                                         if (arrow == null)
                                           arrow = inventoryItems[x].findFirstContainedItem(455);
                                         if (arrow == null) {
                                           arrow = inventoryItems[x].findFirstContainedItem(454);
                                         }
                                    	 if (arrow != null) return arrow;
                                     }
                                   }
                                         arrow = performer.getBody().getBodyItem().findFirstContainedItem(456);
                                         if (arrow == null)
                                           arrow = performer.getBody().getBodyItem().findFirstContainedItem(455);
                                         if (arrow == null)
                                           arrow = performer.getBody().getBodyItem().findFirstContainedItem(454);
                                         if (arrow == null)
                                           arrow = performer.getInventory().findItem(456, true);
                                         if (arrow == null)
                                           arrow = performer.getInventory().findItem(455, true);
                                         if (arrow == null)
                                           arrow = performer.getInventory().findItem(454, true);                                   	 
                                   return arrow;                                   
                       };};}});
           }
       catch (Exception e) {
    	   logger.log(Level.SEVERE, "Failed to apply Archery Find arrow interception", (Throwable)e);
           throw new HookException(e);
       }	   
	   
       try {
           String descriptor = Descriptor.ofMethod(CtPrimitiveType.booleanType, new CtClass[] {
        		   HookManager.getInstance().getClassPool().get("com.wurmonline.server.behaviours.Action"),
                   HookManager.getInstance().getClassPool().get("com.wurmonline.server.creatures.Creature"),
                   HookManager.getInstance().getClassPool().get("com.wurmonline.server.items.Item"),
                   HookManager.getInstance().getClassPool().get("com.wurmonline.server.items.Item"),
                   CtPrimitiveType.shortType,
                   CtPrimitiveType.floatType
           });       	
              HookManager.getInstance().registerHook("com.wurmonline.server.behaviours.ItemBehaviour", "action", descriptor, new InvocationHandlerFactory(){

           	@Override 
                       public InvocationHandler createInvocationHandler(){
                           return new InvocationHandler(){

                               @Override
                               public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                                   Creature performer = (Creature) args[1];
                                   Item source = (Item) args[2];
                                   Item target = (Item) args[3];

                            	   if(source.getTemplateId() == 454 && target.getTemplateId() == 452  ) {
                            	   Item arrow = ItemFactory.createItem(456, source.getQualityLevel(), performer.getName());
                            	   arrow.setMaterial(source.getMaterial());
                            	   performer.getInventory().insertItem(arrow, true);
                            	   performer.getCommunicator().sendActionResult(true);
                            	   Items.destroyItem(target.getWurmId());
                            	   Items.destroyItem(source.getWurmId());
                            	   return true;
                            	   }
                            	   
                            	   if(target.getTemplateId() == 454 && source.getTemplateId() == 452  ) {
                            	   Item arrow = ItemFactory.createItem(456, target.getQualityLevel(), performer.getName());
                            	   arrow.setMaterial(target.getMaterial());
                            	   performer.getInventory().insertItem(arrow, true);
                            	   performer.getCommunicator().sendActionResult(true);
                            	   Items.destroyItem(target.getWurmId());
                            	   Items.destroyItem(source.getWurmId());
                            	   return true;
                            	   }                           	   
                            	   
                            	   
                            	   
                               return method.invoke(proxy, args);
                               };};}});
           }
       catch (Exception e) {
    	   logger.log(Level.SEVERE, "Failed to apply Archery Craft interception", (Throwable)e);
           throw new HookException(e);
       }
       
      try {
           String descriptor = Descriptor.ofMethod(CtPrimitiveType.booleanType, new CtClass[] {
        		   HookManager.getInstance().getClassPool().get("com.wurmonline.server.creatures.Creature"),
                   HookManager.getInstance().getClassPool().get("com.wurmonline.server.creatures.Creature"),
                   HookManager.getInstance().getClassPool().get("com.wurmonline.server.items.Item"),
                   HookManager.getInstance().getClassPool().get("com.wurmonline.server.items.Item"),
                   CtPrimitiveType.doubleType,
                   CtPrimitiveType.floatType,
                   CtPrimitiveType.floatType,
                   CtPrimitiveType.byteType,
                   CtPrimitiveType.booleanType,
                   CtPrimitiveType.booleanType,
                   CtPrimitiveType.doubleType,
                   CtPrimitiveType.doubleType
           });       	
              HookManager.getInstance().registerHook("com.wurmonline.server.combat.Archery", "hit", descriptor, new InvocationHandlerFactory(){

           	@Override 
                       public InvocationHandler createInvocationHandler(){
                           return new InvocationHandler(){

                               @Override
                               public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                                   Creature defender = (Creature) args[0];
                                   Item bow = (Item) args[3];
                                   double damage = (double) args[4];
                                   if (bow != null) {
                                	   damage *= damagefactor;
	                                   if (defender.isUnique()) {
	                                	   damage *= uniquefactor;
	                                   }
	                                   args[4] = (double) damage;
                                   }
                               return method.invoke(proxy, args);
                               };};}});
           }
       catch (Exception e) {
    	   logger.log(Level.SEVERE, "Failed to apply Archery Damage interception", (Throwable)e);
           throw new HookException(e);
       }   

	}
	
}