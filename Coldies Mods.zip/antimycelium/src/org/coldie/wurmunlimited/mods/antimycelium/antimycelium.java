package org.coldie.wurmunlimited.mods.antimycelium;

import org.gotti.wurmunlimited.modloader.interfaces.ServerStartedListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.actions.ModActions;

public class antimycelium implements WurmServerMod, ServerStartedListener {

	@Override
	public void onServerStarted() {
		ModActions.registerAction(new antimyceliumaction());
	}


	
}