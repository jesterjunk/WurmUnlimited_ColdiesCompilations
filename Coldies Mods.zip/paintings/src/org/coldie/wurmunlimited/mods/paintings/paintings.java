package org.coldie.wurmunlimited.mods.paintings;

import java.util.Properties;

import org.gotti.wurmunlimited.modloader.interfaces.Configurable;
import org.gotti.wurmunlimited.modloader.interfaces.ItemTemplatesCreatedListener;
import org.gotti.wurmunlimited.modloader.interfaces.ServerStartedListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.actions.ModActions;


public class paintings implements WurmServerMod, ItemTemplatesCreatedListener, Configurable, ServerStartedListener {

	static int targetid = 9800;
	public static int portraitnumber = 8;
	public static int landscapenumber = 9;
	@Override
	public void onItemTemplatesCreated() {
		new paintingitems();
		
	}
	
    public String getVersion() {
        return "v5.1";
    }

	@Override
	public void configure(Properties properties) {
		targetid = Integer.parseInt(properties.getProperty("targetid", Integer.toString(targetid)));
		portraitnumber = Integer.parseInt(properties.getProperty("portraitnumber", Integer.toString(portraitnumber)));
		landscapenumber = Integer.parseInt(properties.getProperty("landscapenumber", Integer.toString(landscapenumber)));
	}

	@Override
	public void onServerStarted() {
		ModActions.registerAction(new changeportraitaction());
		ModActions.registerAction(new changelandscapeaction());
	}
}