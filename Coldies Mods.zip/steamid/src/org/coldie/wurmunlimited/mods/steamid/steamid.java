package org.coldie.wurmunlimited.mods.steamid;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import org.gotti.wurmunlimited.modloader.interfaces.PlayerLoginListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;

import com.wurmonline.server.DbConnector;
import com.wurmonline.server.players.Player;
import com.wurmonline.server.steam.SteamId;
import com.wurmonline.server.utils.DbUtilities;

public class steamid implements WurmServerMod, PlayerLoginListener {
	static Logger logger = Logger.getLogger(steamid.class.getName());

	@SuppressWarnings("resource")
	@Override
	public void onPlayerLogin(Player arg0) {
		SteamId steamid = arg0.getSteamId();
		boolean found = false;
		boolean first = true;
		long firstused = System.currentTimeMillis();
	    Connection db = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    try
	    {
	      DbUtilities.closeDatabaseObjects(ps, null);
	      db = DbConnector.getPlayerDbCon();
	      ps = db.prepareStatement("SELECT * FROM STEAM_IDS WHERE PLAYER_ID=?");
	      ps.setLong(1, arg0.getWurmId());
	      rs = ps.executeQuery();
	      while (rs.next())
	      {
	    	  if(first) {
	    		  firstused=rs.getLong("FIRST_USED");
	    		  first = false;
	    	  }
	    	  found = true;
	      }
	      
	      if(found) {
	    	  DbUtilities.closeDatabaseObjects(ps, null);
	          db = DbConnector.getPlayerDbCon();
	          ps = db.prepareStatement("DELETE FROM STEAM_IDS WHERE PLAYER_ID=?");
	          ps.setLong(1, arg0.getWurmId());
	          ps.executeUpdate();
	      }
	      long now = System.currentTimeMillis();
    	  DbUtilities.closeDatabaseObjects(ps, null);
          ps = db.prepareStatement("INSERT INTO STEAM_IDS(PLAYER_ID,STEAM_ID,FIRST_USED,LAST_USED) VALUES(?,?,?,?)");
          ps.setLong(1, arg0.getWurmId());
          ps.setLong(2, steamid.getSteamID64());
          ps.setLong(3, firstused);
          ps.setLong(4, now);
          ps.executeUpdate();
          
	      DbUtilities.closeDatabaseObjects(ps, null);
	      db = DbConnector.getPlayerDbCon();
	      ps = db.prepareStatement("SELECT * FROM STEAM_IDS WHERE PLAYER_ID=?");
	      ps.setLong(1, arg0.getWurmId());
	      rs = ps.executeQuery();
	      while (rs.next())
	      {
	    	  found = true;
	      }          
	    }
	    catch (SQLException ex)
	    {

	    }
	    finally
	    {
	      DbUtilities.closeDatabaseObjects(ps, rs);
	      DbConnector.returnConnection(db);
	    }	
		
	}
	
}
