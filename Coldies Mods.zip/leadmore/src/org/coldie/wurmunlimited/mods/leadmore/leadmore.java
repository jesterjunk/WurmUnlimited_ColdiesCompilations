package org.coldie.wurmunlimited.mods.leadmore;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.gotti.wurmunlimited.modloader.classhooks.HookManager;
import org.gotti.wurmunlimited.modloader.interfaces.Initable;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;

import javassist.CannotCompileException;
import javassist.CtClass;
import javassist.NotFoundException;
import javassist.expr.ExprEditor;
import javassist.expr.MethodCall;


public class leadmore implements WurmServerMod, Initable {
	static Logger logger = Logger.getLogger(leadmore.class.getName());	
    
    public String getVersion() {
        return "v3.0";
    }
   
@Override
public void init() {
	mayleadmore();
}

public void mayleadmore() {
    try {
        CtClass ctc = HookManager.getInstance().getClassPool().get("com.wurmonline.server.players.Player");
        ctc.getDeclaredMethod("mayLeadMoreCreatures").instrument(new ExprEditor(){
             public void edit(MethodCall m) throws CannotCompileException {
            	 if (m.getMethodName().equals("size")) {
            		 logger.log(Level.INFO, "lead more hook");
                     m.replace("$_ = ($0.size() - 2);");
                     return;
            	}
            }
           
        });
    }
    catch (CannotCompileException | NotFoundException e) {
        logger.log(Level.SEVERE, "Failed to apply onetilemining interception", (Throwable)e);
    }	  
	  
}
}