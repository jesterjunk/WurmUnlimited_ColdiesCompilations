package org.coldie.wurmunlimited.mods.deedmaker;

import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import com.wurmonline.server.MiscConstants;
import com.wurmonline.server.items.ItemTypes;

import java.io.IOException;

public class deedmakeritems implements WurmServerMod, ItemTypes, MiscConstants {
	
	public deedmakeritems() {
		try {
			com.wurmonline.server.items.ItemTemplateCreator.createItemTemplate(deedmaker.InvitorID, "Village Welcomer", "Village Welcomers", "superb", "good", "ok", "poor", "Activate any item, right click me and click Join Deed to join this deed.", new short[]{108, 52, 22, 92, 157, 31, 67, 40, 123},(short) 282,(short) 1, 0, 2419200, 3, 5, 20, -10, MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY, deedmaker.InvitorModel, 20.0f, 1000, (byte) 0, 10000, true);
		}catch(IOException e){
		}		
	}
	
}