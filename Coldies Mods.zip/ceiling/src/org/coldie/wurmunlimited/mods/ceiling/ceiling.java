package org.coldie.wurmunlimited.mods.ceiling;

import java.util.Properties;

import org.gotti.wurmunlimited.modloader.interfaces.Configurable;
import org.gotti.wurmunlimited.modloader.interfaces.ItemTemplatesCreatedListener;
import org.gotti.wurmunlimited.modloader.interfaces.ServerStartedListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.actions.ModActions;

public class ceiling implements WurmServerMod, Configurable, ServerStartedListener, ItemTemplatesCreatedListener  {
	public static int itemtemplate1 = 8263;
	public static String itemmodel1 = "model.structure.floor.wood.";
	
    public String getVersion() {
        return "v1.1";
    }
    
	@Override
	public void onServerStarted() {
		ModActions.registerAction(new raiseaction());
	}

	@Override
	public void configure(Properties properties) {
		itemtemplate1 = Integer.parseInt(properties.getProperty("itemtemplate1", Float.toString(itemtemplate1)));
		itemmodel1 = properties.getProperty("itemmodel1",itemmodel1);		
	}

	public void onItemTemplatesCreated() {
		new ceilingitems();
	}	


}