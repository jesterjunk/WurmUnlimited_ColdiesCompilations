package com.wurmonline.server.questions;


import com.wurmonline.server.Server;
import com.wurmonline.server.behaviours.Action;
import com.wurmonline.server.behaviours.NoSuchActionException;
import com.wurmonline.server.creatures.Creature;
import java.util.Properties;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.gotti.wurmunlimited.modsupport.ModSupportDb;

import net.coldie.wurmunlimited.mods.eventportals.manageeventaction;
import net.coldie.wurmunlimited.mods.eventportals.eventmod;
import net.coldie.tools.BmlForm;

public class manageeventquestion extends Question
{
	  private boolean properlySent = false;
	  
	  manageeventquestion(Creature aResponder, String aTitle, String aQuestion, int aType, long aTarget)
	  {
	    super(aResponder, aTitle, aQuestion, aType, aTarget);
	  }
	  
	  public manageeventquestion(Creature aResponder, String aTitle, String aQuestion, long aTarget)
	  {
	    super(aResponder, aTitle, aQuestion, 79, aTarget);
	  }
	  


	  public void answer(Properties answer)
	  {
	    if (!properlySent) {
	      return;
	    }

	    // check drop down and accepted
	    boolean accepted = (answer.containsKey("accept")) && (answer.get("accept") == "true");

	    if (accepted)
	    {
	    	String val = answer.getProperty("event");
	    	 if (val == null || val.equals("eventnzenny")){
	    	eventmod.activated = true;
	    	 eventmod.zennyactivated = true;
		     Connection dbcon2 = null;
		      PreparedStatement ps2 = null;	    	
		      try
		      {	      
			      dbcon2 = ModSupportDb.getModSupportDb();
			      ps2 = dbcon2.prepareStatement("UPDATE ColdieEventPortals "
			      + "SET posx = " + getResponder().getPosX()
			      +",posy = " + getResponder().getPosY()
			      +",layer = " + getResponder().getLayer()
			      +",floorlevel = " + getResponder().getFloorLevel()			      
			      + " WHERE id = 1");
			      ps2.executeUpdate();
			      ps2.close();    		  
			      getResponder().getCommunicator().sendNormalServerMessage("Activating event portal");
			      Server.getInstance().broadCastAlert("Event Portal Activated", false, (byte)1);
			      eventmod.active = true;
		    }
	      catch (SQLException e) {
	          throw new RuntimeException(e);
	        }	
		      		 		      
		      
	    	 }else{		      
	    		 eventmod.zennyactivated = true;
	    	 }
	    }else{
	    	eventmod.activated = false;
	    	eventmod.zennyactivated = false;
		     Connection dbcon5 = null;
		      PreparedStatement ps5 = null;	    	
		      try
		      {	      
			      dbcon5 = ModSupportDb.getModSupportDb();
			      ps5 = dbcon5.prepareStatement("UPDATE ColdieEventPortals "
			      + "SET posx = 1 WHERE id = 1");
			      ps5.executeUpdate();
			      ps5.close();    		  
			      getResponder().getCommunicator().sendNormalServerMessage("Deactivating event portal"); 
			      Server.getInstance().broadCastAlert("Event Portal Deactivated", false, (byte)1);
			      eventmod.active = false;
		    }
	      catch (SQLException e) {
	          throw new RuntimeException(e);
	        }	    		    	
	    }
 
	    }


	  public void sendQuestion()
	  {
	    boolean ok = true;
	    

	      try {
	        ok = false;
	        Action act = getResponder().getCurrentAction();
	        if (act.getNumber() == manageeventaction.actionId) {
	          ok = true;
	        }
	      }
	      catch (NoSuchActionException act) {
	        throw new RuntimeException("No such action", act);
	      }
	      
	    if (ok) {
	      properlySent = true;
 
	      BmlForm f = new BmlForm("");
	      
	      f.addHidden("id", id+"");
	      f.addBoldText(getQuestion(), new String[0]);
	      f.addText("\n ", new String[0]);

	      f.addRaw("radio{ group='event'; id='eventnzenny';text='Activate event'}");
	      
	      f.addText("\n\n\n\n ", new String[0]);
	      f.beginHorizontalFlow();
	 	  f.addButton("Start Event", "accept");
	      f.addText("               ", new String[0]);
	      f.addButton("End Event", "decline");
	      
	      
	      f.endHorizontalFlow();
	      f.addText(" \n", new String[0]);
	      f.addText(" \n", new String[0]);
	      
	      getResponder().getCommunicator().sendBml(
	        300, 
	        250, 
	        true, 
	        true, 
	        f.toString(), 
	        150, 
	        150, 
	        200, 
	        title);
	    }
	  }

}