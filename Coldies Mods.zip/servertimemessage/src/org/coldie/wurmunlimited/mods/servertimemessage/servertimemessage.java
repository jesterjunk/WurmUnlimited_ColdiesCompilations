package org.coldie.wurmunlimited.mods.servertimemessage;

import java.util.Properties;

import org.gotti.wurmunlimited.modloader.interfaces.Configurable;
import org.gotti.wurmunlimited.modloader.interfaces.PlayerMessageListener;
import org.gotti.wurmunlimited.modloader.interfaces.ServerPollListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;

import com.wurmonline.server.Server;
import com.wurmonline.server.creatures.Communicator;
import com.wurmonline.server.players.Player;

import java.text.SimpleDateFormat;

public class servertimemessage implements WurmServerMod, Configurable, ServerPollListener, PlayerMessageListener {
	 static long lastPoll = System.currentTimeMillis();
	 static long currmillis = System.currentTimeMillis();
	 static int pollFrequency = (5*1000); //5 seconds 
	 final SimpleDateFormat dfh = new SimpleDateFormat("HH");
	 final SimpleDateFormat dfm = new SimpleDateFormat("mm");
	 final SimpleDateFormat dft = new SimpleDateFormat("HH:mm");
	 static boolean time30 = false;
	 static boolean time10 = false;
	 static boolean time5 = false;
	 static boolean time2 = false;
	 static boolean time1 = false;
	 static int alarmhour = 5;
	 static int alarmminute = 55;
	 
	 
	@Override
	public void configure(Properties properties) {
		alarmhour = Integer.parseInt(properties.getProperty("alarmhour", Integer.toString(alarmhour)));
		alarmminute = Integer.parseInt(properties.getProperty("alarmminute", Integer.toString(alarmminute)));
	}

    @Override
    public boolean onPlayerMessage(Communicator communicator, String msg) {
        if (msg.startsWith("/servertime")) {
        	Player player = communicator.player;
        	if(player.getPower() > 3) {
        		String DFH = dft.format(System.currentTimeMillis());
        		player.getCommunicator().sendNormalServerMessage("Server time is "+DFH);
        	}
        	return true;
        }
        return false;
    }
    
	@Override
	public void onServerPoll() {
		currmillis = System.currentTimeMillis();
		 if (lastPoll + pollFrequency > currmillis) {
		      return;
		     }
		 lastPoll = currmillis;
		 String DFH = dfh.format(currmillis);
		 String DFM = dfm.format(currmillis);
		 int DH = Integer.parseInt(DFH);
		 int DM = Integer.parseInt(DFM);
		 if(time30 == false && DH == alarmhour && DM == alarmminute-30) {
			 Server.getInstance().broadCastAlert("The server is rebooting in 30 minutes. ", true, (byte)1);
		 	time30 = true;
		 	}
		 if(time10 == false && DH == alarmhour && DM == alarmminute-10) {
			 Server.getInstance().broadCastAlert("The server is rebooting in 10 minutes. ", true, (byte)1);
		 	time10 = true;
		 	}
		 if(time5 == false && DH == alarmhour && DM == alarmminute-5) {
			 Server.getInstance().broadCastAlert("The server is rebooting in 5 minutes. ", true, (byte)1);
		 	time5 = true;
		 	}
		 if(time2 == false && DH == alarmhour && DM == alarmminute-2) {
			 Server.getInstance().broadCastAlert("The server is rebooting in 2 minutes. ", true, (byte)1);
		 	time2 = true;
		 	}
		 if(time1 == false && DH == alarmhour && DM == alarmminute-1) {
			 Server.getInstance().broadCastAlert("The server is rebooting in 1 minute. ", true, (byte)1);
		 	time1 = true;
		 	}
	}
}