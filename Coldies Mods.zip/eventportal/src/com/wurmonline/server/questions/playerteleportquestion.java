package com.wurmonline.server.questions;


import com.wurmonline.server.behaviours.Action;
import com.wurmonline.server.behaviours.NoSuchActionException;
import com.wurmonline.server.creatures.Creature;
import java.util.Properties;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.gotti.wurmunlimited.modsupport.ModSupportDb;

import net.coldie.wurmunlimited.mods.eventportals.eventaction;

import net.coldie.tools.BmlForm;

public class playerteleportquestion extends Question
{
	  private boolean properlySent = false;
	  
	  playerteleportquestion(Creature aResponder, String aTitle, String aQuestion, int aType, long aTarget)
	  {
	    super(aResponder, aTitle, aQuestion, aType, aTarget);
	  }
	  
	  public playerteleportquestion(Creature aResponder, String aTitle, String aQuestion, long aTarget)
	  {
	    super(aResponder, aTitle, aQuestion, 79, aTarget);
	  }
	  


	  public void answer(Properties answer)
	  {
	    if (!properlySent) {
	      return;
	    }
	    // check drop down and accepted
	    boolean accepted = (answer.containsKey("accept")) && (answer.get("accept") == "true");
	      float tx = 100;
	      float ty = 100;	
	      int floorlevel = 0;
	      int layer = 0;
	    if (accepted)
	    {
		      Connection dbcon = null;
		      PreparedStatement ps = null;
		      ResultSet rs = null;
		      try
		      {	      
		      dbcon = ModSupportDb.getModSupportDb();
		      ps = dbcon.prepareStatement("SELECT * FROM ColdieEventPortals WHERE id = 1");
		      rs = ps.executeQuery();
			  tx = (rs.getFloat("posx"));
			  ty = (rs.getFloat("posy"));
		      floorlevel = (rs.getInt("floorlevel"));
		      layer = (rs.getInt("layer"));
		      rs.close();
		      ps.close();
		      dbcon.close();
			    }
		      catch (SQLException e) {
		          throw new RuntimeException(e);
		        }
		      
			      Connection dbcon3 = null;
			      PreparedStatement ps1 = null;	
			      dbcon3 = ModSupportDb.getModSupportDb();
			      try
			      {	      
				      ps1 = dbcon3.prepareStatement("UPDATE ColdieEventPortals "
						      + "SET posx = " + getResponder().getPosX()
						      +",posy = " + getResponder().getPosY()
						      +",layer = " + getResponder().getLayer()
						      +",floorlevel = " + getResponder().getFloorLevel()
						      + " WHERE id = "+ getResponder().getWurmId());

				      ps1.executeUpdate();
				      ps1.close();    		  
			    }
		      catch (SQLException e) {
		          throw new RuntimeException(e);
		        }	    	  

			getResponder().setTeleportPoints(tx, ty, layer, floorlevel);
			getResponder().startTeleporting();
			getResponder().getCommunicator().sendNormalServerMessage("You feel a slight tingle in your spine.");
			getResponder().getCommunicator().sendTeleport(false);
			getResponder().teleport(true);
			getResponder().stopTeleporting();
			}
	  }

	  public void sendQuestion()
	  {
	    boolean ok = true;
	    

	      try {
	        ok = false;
	        Action act = getResponder().getCurrentAction();
	        if (act.getNumber() == eventaction.actionId) {
	          ok = true;
	        }
	      }
	      catch (NoSuchActionException act) {
	        throw new RuntimeException("No such action", act);
	      }
	      
	    if (ok) {
	      properlySent = true;

	      BmlForm f = new BmlForm("");
	      
	      f.addHidden("id", id+"");
	      f.addBoldText(getQuestion(), new String[0]);
	      f.addText("\n ", new String[0]);

	      f.addText("\n\n\n\n ", new String[0]);
	      f.beginHorizontalFlow();
	 	  f.addButton("Teleport now", "accept");
	      f.addText("               ", new String[0]);
	      f.addButton("Cancel", "decline");
	      
	      
	      f.endHorizontalFlow();
	      f.addText(" \n", new String[0]);
	      f.addText(" \n", new String[0]);
	      
	      getResponder().getCommunicator().sendBml(
	        300, 
	        250, 
	        true, 
	        true, 
	        f.toString(), 
	        150, 
	        150, 
	        200, 
	        title);
	    }
	  }

}