package org.coldie.wurmunlimited.mods.archery;

import java.util.Arrays;
import java.util.List;

import org.gotti.wurmunlimited.modloader.ReflectionUtil;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.actions.ActionPerformer;
import org.gotti.wurmunlimited.modsupport.actions.BehaviourProvider;
import org.gotti.wurmunlimited.modsupport.actions.ModAction;
import org.gotti.wurmunlimited.modsupport.actions.ModActions;

import com.wurmonline.server.MiscConstants;
import com.wurmonline.server.behaviours.Action;
import com.wurmonline.server.behaviours.ActionEntry;
import com.wurmonline.server.creatures.Creature;
import com.wurmonline.server.items.Item;
import com.wurmonline.server.items.ItemTypes;
import com.wurmonline.server.players.Player;

public class archeryloreaction implements WurmServerMod, ItemTypes, MiscConstants, ModAction, BehaviourProvider, ActionPerformer {

	public static short actionId;
	static ActionEntry actionEntry;

	public archeryloreaction() {
		actionId = (short) ModActions.getNextActionId();
		actionEntry = ActionEntry.createEntry(actionId, "Get archery info", "Geting archery info", new int[]{ 
				}); 
		ModActions.registerAction(actionEntry);
		try {
			ReflectionUtil.setPrivateField(actionEntry, ReflectionUtil.getField(actionEntry.getClass(), "ignoresRange"), true);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassCastException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		}
	}

	@Override
	public BehaviourProvider getBehaviourProvider() {
		return this;
	}

	@Override
	public ActionPerformer getActionPerformer() {
		return this;
	}

	@Override
	public short getActionId() {
		return actionId;
	}

	@Override
	public List<ActionEntry> getBehavioursFor(Creature performer,Item source, Creature target) {
		if (performer instanceof Player) {
			if (source.isWeaponBow()) {
				return (List<ActionEntry>) Arrays.asList(actionEntry);
			} else {
				return null;
			}
		} else {
			return null;
		}
	}
	
	@Override
	public boolean action(Action act, Creature performer, Item source, Creature target, short action, float counter) {

		if (performer instanceof Player && source.isWeaponBow()) {
			int dist = (int)Creature.getRange(performer, target.getPosX(), target.getPosY());
			int ideal = 0;
			switch (source.getTemplateId())
			{
			case 447:
				ideal = 20;
				break;
			case 448:
				ideal = 40;
				break;
			case 449:
				ideal = 80;
				break;
			}
			performer.getCommunicator().sendSafeServerMessage("Distance to mob: "+dist+" meters, ideal is "+ideal);
				return true;
			}
			return false;
	}
	
    
}