package org.coldie.wurmunlimited.mods.creaturesdb;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;


import org.gotti.wurmunlimited.modloader.interfaces.ServerStartedListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;

import com.wurmonline.server.DbConnector;
import com.wurmonline.server.utils.DbUtilities;

public class creaturesdb implements WurmServerMod, ServerStartedListener {
	static Logger logger = Logger.getLogger(creaturesdb.class.getName());
	public static HashMap<Integer, Long> position = new HashMap<Integer,Long>();
	public static HashMap<Integer, Long> creatures = new HashMap<Integer,Long>();
	public static HashMap<Integer, Long> deleteit = new HashMap<Integer,Long>();
	
	

	@Override
	public void onServerStarted() {
		
		findallid();
		findmissingid();
		deleteids();
		
	}
	
	void findallid() {
    	Connection db = null;
        PreparedStatement ps = null;
        ResultSet rs = null;	    
	    try
	    {

	      DbUtilities.closeDatabaseObjects(ps, null);
	      db = DbConnector.getCreatureDbCon();
	      ps = db.prepareStatement("SELECT * FROM POSITION");
	      rs = ps.executeQuery();
	      int count = 1;
	      while (rs.next())
	      {
	    	  position.put(count, rs.getLong("WURMID"));
	    	  count = count+1;
	      }
	      
	      }
	    catch (SQLException ex)
	    {
		      DbUtilities.closeDatabaseObjects(ps, null);
		      DbConnector.returnConnection(db);
	    }
	    
	    finally
	    {
	      DbUtilities.closeDatabaseObjects(ps, null);
	      DbConnector.returnConnection(db);
	    }
	    
	    
	      DbUtilities.closeDatabaseObjects(ps, null);
	      DbConnector.returnConnection(db);
	}
	
	
	void findmissingid() {
		logger.log(Level.INFO, "looking size: "+position.size());
    	Connection db = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
	    try
	    {
	      db = DbConnector.getCreatureDbCon();
	      ps = db.prepareStatement("SELECT * FROM CREATURES");
	      rs = ps.executeQuery(); 
	      int count = 1;
	      while (rs.next())
	      {	      
	    	  creatures.put(count, rs.getLong("WURMID")); count = count + 1;
	      }
	    }
		    catch (SQLException ex)
		    {
			      DbUtilities.closeDatabaseObjects(ps, null);
			      DbConnector.returnConnection(db);
		    }
		    
		    finally
		    {
		      DbUtilities.closeDatabaseObjects(ps, null);
		      DbConnector.returnConnection(db);
		    }
		      DbUtilities.closeDatabaseObjects(ps, null);
		      DbConnector.returnConnection(db);	
	}
	
	@SuppressWarnings("resource")
	void deleteids() {
		int count = 1;
		for (long g : position.values() ) {
			if(!creatures.containsValue(g)) deleteit.put(count,g); count = count +1;
		}
		
		logger.log(Level.INFO, "deleteit size: "+deleteit.size());
		Connection db = null;
	    PreparedStatement ps = null;
		    for (Long i : deleteit.values()) {
			    try
			    {
			      db = DbConnector.getCreatureDbCon();

		          ps = db.prepareStatement("DELETE FROM CREATURES WHERE WURMID="+i);
		          ps.executeUpdate();
		          
		          ps = db.prepareStatement("DELETE FROM BRANDS WHERE WURMID=?");
		          ps.setLong(1, i);
		          ps.executeUpdate();
		          
		          ps = db.prepareStatement("DELETE FROM OFFSPRING WHERE FATHERID=?");
		          ps.setLong(1, i);
		          ps.executeUpdate();
		          
		          ps = db.prepareStatement("DELETE FROM OFFSPRING WHERE MOTHERID=?");
		          ps.setLong(1, i);
		          ps.executeUpdate();		          
		          
		          ps = db.prepareStatement("DELETE FROM POSITION WHERE WURMID=?");
		          ps.setLong(1, i);
		          ps.executeUpdate();
		          
		          ps = db.prepareStatement("DELETE FROM PROTECTED WHERE WURMID=?");
		          ps.setLong(1, i);
		          ps.executeUpdate();	
		          
		          ps = db.prepareStatement("DELETE FROM SKILLS WHERE OWNER=?");
		          ps.setLong(1, i);
		          ps.executeUpdate();	          
	
		          ps = db.prepareStatement("DELETE FROM ANIMALSETTINGS WHERE WURMID=?");
		          ps.setLong(1, i);
		          ps.executeUpdate();
		          
		          
		          logger.log(Level.WARNING, "Removing creature with WURMID: "+ i);

		      DbUtilities.closeDatabaseObjects(ps, null);
		    }
		    catch (SQLException ex)
		    {
			      DbUtilities.closeDatabaseObjects(ps, null);
			      DbConnector.returnConnection(db);
		    }
		    
		    finally
		    {
		      DbUtilities.closeDatabaseObjects(ps, null);
		      DbConnector.returnConnection(db);
		    }	
		      DbUtilities.closeDatabaseObjects(ps, null);
		      DbConnector.returnConnection(db);	
		}
		      logger.log(Level.INFO, "Removed total: "+deleteit.size()+" from creatres.db");
	}
}