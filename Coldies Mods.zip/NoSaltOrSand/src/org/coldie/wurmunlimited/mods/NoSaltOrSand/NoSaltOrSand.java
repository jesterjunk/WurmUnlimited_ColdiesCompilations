package org.coldie.wurmunlimited.mods.NoSaltOrSand;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.gotti.wurmunlimited.modloader.classhooks.HookManager;
import org.gotti.wurmunlimited.modloader.interfaces.Configurable;
import org.gotti.wurmunlimited.modloader.interfaces.Initable;
import org.gotti.wurmunlimited.modloader.interfaces.ServerStartedListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;

import javassist.CannotCompileException;
import javassist.CtClass;
import javassist.NotFoundException;
import javassist.expr.ExprEditor;
import javassist.expr.MethodCall;

public class NoSaltOrSand implements WurmServerMod, Configurable, Initable, ServerStartedListener {
	static Logger logger = Logger.getLogger(NoSaltOrSand.class.getName());
	
	@Override
	public void onServerStarted() {
		
	}

	@Override
	public void configure(Properties arg0) {
		
	}

	@Override
	public void init() {
		 replacemethod();
	}	
    
	private void replacemethod(){
       try {
            CtClass ctc = HookManager.getInstance().getClassPool().get("com.wurmonline.server.zones.TilePoller");
            ctc.getDeclaredMethod("pollNextTile").instrument(new ExprEditor(){
                 public void edit(MethodCall m) throws CannotCompileException {   
                	 if (m.getMethodName().equals("nextInt")) {
                		 logger.log(Level.INFO, "replacing random int with 5.");
		                 m.replace("$_ = 5;");
		                 return;
                	}
                }
               
            });
        }
        catch (CannotCompileException | NotFoundException e) {
            logger.log(Level.SEVERE, "Failed to apply No salt or sand interception", (Throwable)e);
        }
	}
	
	
}