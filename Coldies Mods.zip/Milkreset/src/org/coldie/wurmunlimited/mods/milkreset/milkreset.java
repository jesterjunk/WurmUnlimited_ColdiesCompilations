package org.coldie.wurmunlimited.mods.milkreset;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.gotti.wurmunlimited.modloader.interfaces.Configurable;
import org.gotti.wurmunlimited.modloader.interfaces.PlayerMessageListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;

import com.wurmonline.server.NoSuchPlayerException;
import com.wurmonline.server.Players;
import com.wurmonline.server.creatures.Communicator;
import com.wurmonline.server.creatures.Creature;
import com.wurmonline.server.creatures.Creatures;
import com.wurmonline.server.players.Player;

public class milkreset implements PlayerMessageListener, Configurable, WurmServerMod {
	static long lastdidmilkable = System.currentTimeMillis();
	static int milkhours = 1;
	static int GMlevel = 0;
	static Logger logger = Logger.getLogger(milkreset.class.getName());	
    
    public String getVersion() {
        return "v3.0";
    }
   
	@Override
	public void configure(Properties properties) {
		GMlevel = Integer.parseInt(properties.getProperty("GMlevel", Float.toString(GMlevel)));
		milkhours = Integer.parseInt(properties.getProperty("milkhours", Float.toString(milkhours)));
	}	
	
	public void resetmilk() {
		logger.log(Level.INFO, "Milking reset");
	      Creature[] crets = Creatures.getInstance().getCreatures();
	      for (int x = 0; x < crets.length; ++x) {
	    	  if (crets[x].isMilkable()){
	    		  crets[x].setMilked(false);
	    	  }
	    	  if (crets[x].isSheared()){
	    		  crets[x].setSheared(false);
	    	  }
	      }
	}	
	
	@Override
	public boolean onPlayerMessage(Communicator communicator, String msg) {
		msg = msg.toLowerCase();
		long wurmid = communicator.player.getWurmId();
		Player p;
		try {
			p = Players.getInstance().getPlayer(wurmid);
			//communicator.sendNormalServerMessage("GM level: "+p.getPower());
			if (p.getPower() >= GMlevel && msg.startsWith("/milk") || msg.startsWith("/shear")) {
		        float timeleft = (1000 * 60 * 60 * milkhours) - (System.currentTimeMillis() - lastdidmilkable);
				if(0 >= timeleft) {
					resetmilk();
					lastdidmilkable = System.currentTimeMillis();
					communicator.sendNormalServerMessage("Milking and shearing is possible again.");
				}else {
					if (timeleft > 60000) {
						communicator.sendNormalServerMessage("Time until next reset: "+(int)Math.floor(timeleft/60000)+" minutes");
					}else {
						communicator.sendNormalServerMessage("Time until next reset: "+(int)Math.floor(timeleft/1000)+" seconds");					
					}
				}
				return true;
			}			
			
		} catch (NoSuchPlayerException e) {
			e.printStackTrace();
		}

		return false;
	}
}