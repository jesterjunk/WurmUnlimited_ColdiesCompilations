package org.coldie.wurmunlimited.mods.combiner;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.gotti.wurmunlimited.modloader.ReflectionUtil;
import org.gotti.wurmunlimited.modloader.interfaces.Configurable;
import org.gotti.wurmunlimited.modloader.interfaces.ServerStartedListener;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;


import com.wurmonline.server.items.ItemTemplate;
import com.wurmonline.server.items.ItemTemplateFactory;
import com.wurmonline.server.items.NoSuchTemplateException;

public class combiner implements WurmServerMod, ServerStartedListener, Configurable {
	static Logger logger = Logger.getLogger(combiner.class.getName());
	
    public String getVersion() {
        return "v1.2";
    }
    
	static String [] combinelistid ;
	@Override
	public void onServerStarted() {
		for (int x=0;x<combinelistid.length;x++) {
	        ItemTemplate Combined;
			try {
				Combined = ItemTemplateFactory.getInstance().getTemplate(Integer.parseInt(combinelistid[x]));
				logger.log(Level.INFO, "ID: "+combinelistid[x]+" Name:"+Combined.getName());
		        ReflectionUtil.setPrivateField(Combined, ReflectionUtil.getField(Combined.getClass(), "combineCold"), true);
		        ReflectionUtil.setPrivateField(Combined, ReflectionUtil.getField(Combined.getClass(), "combine"), true);			
				
			} catch (IllegalArgumentException | IllegalAccessException | ClassCastException | NoSuchFieldException | NoSuchTemplateException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	@Override
	public void configure(Properties properties) {
		combinelistid = properties.getProperty("combinelistid").split(";");
	}
}